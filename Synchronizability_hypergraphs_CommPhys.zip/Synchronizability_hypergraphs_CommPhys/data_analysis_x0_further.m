clear all 
close all 
clc

n_topologie_gruppo=100;

n_gruppi_K=5;
n_gruppi_R=10;

load("hyp_kur_x0_further.mat");
KUR=RISULTATI_FINALI;

load("hyp_ross_x0_further_1.mat")
ROSS=RISULTATI_FINALI;
load("hyp_ross_x0_further_2.mat")
ROSS=[ROSS RISULTATI_FINALI];
load("hyp_ross_x0_further_3.mat")
ROSS=[ROSS RISULTATI_FINALI];


set(groot,'defaultAxesTickLabelInterpreter','latex')
set(groot,'defaultTextInterpreter','latex')

matrice_stim_kur=zeros(n_topologie_gruppo,n_gruppi_K);
matrice_eff_kur=zeros(n_topologie_gruppo,n_gruppi_K);
matrice_stim_ross=zeros(n_topologie_gruppo,n_gruppi_R);
matrice_eff_ross=zeros(n_topologie_gruppo,n_gruppi_R);

quante_reti_non_sincronizzano_K=zeros(1,n_gruppi_K);
quante_reti_non_sincronizzano_R=zeros(1,n_gruppi_R);


for j=1:n_gruppi_K

    gruppo=KUR{j};

    for i=1:n_topologie_gruppo
    
        matrice_eff_kur(i,j)=gruppo(i).bound_effettivo;
        matrice_stim_kur(i,j)=gruppo(i).bound_stimato;

        if matrice_eff_kur(i,j)>3 

            quante_reti_non_sincronizzano_K(j)=quante_reti_non_sincronizzano_K(j)+1;

        end

        if matrice_eff_kur(i,j)>3 && j<n_gruppi_K

            matrice_eff_kur(i,j)=NaN;
            matrice_stim_kur(i,j)=NaN;

        end
    
    end

end

quante_hp_insoddisfatte_R=zeros(1,n_gruppi_R);

for j=1:n_gruppi_R

    gruppo=ROSS{j};

    for i=1:n_topologie_gruppo
    
        matrice_eff_ross(i,j)=gruppo(i).bound_effettivo;
        matrice_stim_ross(i,j)=gruppo(i).bound_stimato;

        if matrice_eff_ross(i,j)>3

            quante_reti_non_sincronizzano_R(j)=quante_reti_non_sincronizzano_R(j)+1;

            matrice_eff_ross(i,j)=NaN;
            matrice_stim_ross(i,j)=NaN;

        end

        if matrice_stim_ross(i,j)<0

            quante_hp_insoddisfatte_R(j)=quante_hp_insoddisfatte_R(j)+1;

            matrice_eff_ross(i,j)=NaN;
            matrice_stim_ross(i,j)=NaN;

        end
    
    end

end

set(groot,'defaultAxesTickLabelInterpreter','latex')
set(groot,'defaultTextInterpreter','latex')

vettore_pearson_K=zeros(1,n_gruppi_K);
vettore_kendall_K=zeros(1,n_gruppi_K);
vettore_rquadro_K=zeros(1,n_gruppi_K);
matrice_parametri_K=zeros(2,n_gruppi_K);

vettore_pearson_R=zeros(1,n_gruppi_R);
vettore_kendall_R=zeros(1,n_gruppi_R);
vettore_rquadro_R=zeros(1,n_gruppi_R);
matrice_parametri_R=zeros(2,n_gruppi_R);

for i=1:n_gruppi_K

    vettore_stim=matrice_stim_kur(:,i);
    vettore_eff=matrice_eff_kur(:,i);

    vettore_stim=vettore_stim(~isnan(vettore_stim));
    vettore_eff=vettore_eff(~isnan(vettore_eff));

    mdl_kur=fitlm(vettore_eff,vettore_stim); %Correlazioni "a pezzi"
    vettore_pearson_K(i)=corr(vettore_eff,vettore_stim);
    vettore_kendall_K(i)=corr(vettore_eff,vettore_stim,"Type","Kendall");
    vettore_rquadro_K(i)=mdl_kur.Rsquared.Ordinary;
    matrice_parametri_K(:,i)=mdl_kur.Coefficients.Estimate;

end

for i=1:n_gruppi_R

    vettore_stim=matrice_stim_ross(:,i);
    vettore_eff=matrice_eff_ross(:,i);

    vettore_stim=vettore_stim(~isnan(vettore_stim));
    vettore_eff=vettore_eff(~isnan(vettore_eff));

    mdl_ross=fitlm(vettore_eff,vettore_stim); %Correlazioni "a pezzi"
    vettore_pearson_R(i)=corr(vettore_eff,vettore_stim);
    vettore_kendall_R(i)=corr(vettore_eff,vettore_stim,"Type","Kendall");
    vettore_rquadro_R(i)=mdl_ross.Rsquared.Ordinary;
    matrice_parametri_R(:,i)=mdl_ross.Coefficients.Estimate;

end

a = 8; % Aumentato leggermente per marker più grandi
spessore_linea = 2; % Variabile per rendere le linee più doppie

vettore_ascisse = 1:n_gruppi_K;

subplot(1,2,1)

% Grafico Pearson
plot(vettore_ascisse, vettore_pearson_K, '-d', 'LineWidth', spessore_linea, 'MarkerSize', a, 'DisplayName', 'Pearson'); 
hold on

% Grafico Kendall
plot(vettore_ascisse, vettore_kendall_K, '-d', 'LineWidth', spessore_linea, 'MarkerSize', a, 'DisplayName', 'Kendall'); 

% Grafico R^2 (usando l'interprete latex per la stringa se necessario)
plot(vettore_ascisse, vettore_rquadro_K, '-d', 'LineWidth', spessore_linea, 'MarkerSize', a, 'DisplayName', '$R^2$'); 

% Linea di riferimento (esclusa dalla legenda con HandleVisibility)
plot(vettore_ascisse, ones(size(vettore_ascisse)), '--k', 'LineWidth', 1.5, 'HandleVisibility', 'off'); 

% Configurazione Legenda (attivando l'interprete latex per mostrare correttamente R^2)
lgd = legend('Location', 'southwest', 'Interpreter', 'latex');
lgd.FontSize = 12; % Aumentato per migliorarne la leggibilità insieme al font generale

% Personalizzazione Assi e Titoli
title('Kuramoto model')
xlabel("$\varsigma$", 'Interpreter', 'latex')

limy = [-0.4 1.2];
ylim(limy)

xticks(1:n_gruppi_K)
xticklabels({'0.1', '0.2', '0.5', '1', '2'})

yticks(-0.4:0.2:1.2)
yticklabels(-0.4:0.2:1.2)

set(gca, 'FontSize', 15)
hold off


subplot(1,2,2)

vettore_ascisse=1:n_gruppi_R;

% Grafico Pearson
plot(vettore_ascisse, vettore_pearson_R, '-d', 'LineWidth', spessore_linea, 'MarkerSize', a, 'DisplayName', 'Pearson'); 
hold on

% Grafico Kendall
plot(vettore_ascisse, vettore_kendall_R, '-d', 'LineWidth', spessore_linea, 'MarkerSize', a, 'DisplayName', 'Kendall'); 

% Grafico R^2 (usando l'interprete latex per la stringa se necessario)
plot(vettore_ascisse, vettore_rquadro_R, '-d', 'LineWidth', spessore_linea, 'MarkerSize', a, 'DisplayName', '$R^2$'); 

% Linea di riferimento (esclusa dalla legenda con HandleVisibility)
plot(vettore_ascisse, ones(size(vettore_ascisse)), '--k', 'LineWidth', 1.5, 'HandleVisibility', 'off'); 

% Configurazione Legenda (attivando l'interprete latex per mostrare correttamente R^2)
lgd = legend('Location', 'southwest', 'Interpreter', 'latex');
lgd.FontSize = 12; % Aumentato per migliorarne la leggibilità insieme al font generale

% Personalizzazione Assi e Titoli
title('R\"ossler systems')
xlabel("$\varsigma$", 'Interpreter', 'latex')


limy = [0 1.2];
ylim(limy)
xlim([1 n_gruppi_R])

xticks(1:n_gruppi_R)
xticklabels({'0.1', '0.2', '0.5', '1', '2', '5', '10', '20', '50', '100'})

yticks(0:0.2:1.2)
yticklabels(0:0.2:1.2)

set(gca, 'FontSize', 15)
hold off



% set(gca,'FontSize',15)
% 
set(gcf, 'Position',  [250, 125, 1025, 400]);
% 

