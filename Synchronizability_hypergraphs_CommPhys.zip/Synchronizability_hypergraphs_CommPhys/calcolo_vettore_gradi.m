function [vettore_gradi] = calcolo_vettore_gradi(matrice)
    
    vettore_gradi=zeros(1,size(matrice,2));

    for i=1:size(matrice,2)

        for j=1:size(matrice,1)

            if matrice(j,i)>0

                vettore_gradi(i)=vettore_gradi(i)+1;

            end

        end

    end

end