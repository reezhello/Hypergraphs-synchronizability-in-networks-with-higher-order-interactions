function [L, A, AS_piu] = adiacenza_e_laplaciano(mat_e_testa_di, mat_e_coda_di, N, n_iperarchi, sigma2, sigma3)

    A=zeros(N,N);
    AS_piu=zeros(N,N);

    alfa=cell(n_iperarchi,1);
    beta=cell(n_iperarchi,1);
    
    %%Qui implemento la soluzione presente nel paper che ho usato per la
    %%tesina. Le soluzioni sono identiche solo che in questo caso non utilizzo
    %%i vettori alfa e beta di N componenti di cui molte sono 0. Utilizzo degli
    %%alfa e dei beta che contengono tante componenti (tutte uguali) quante
    %%sono le teste e le code di un dato iperarco.
    
    for j=1:n_iperarchi 
    
        o=0;
        y=0;
    
        for i=1:N
    
            if mat_e_coda_di(j,i) > 0    %%Tengo conto di quante code ci sono nel j-esimo iperarco
                
                o=o+1;
    
            end
    
            if mat_e_testa_di(j,i) > 0   %%Tengo conto di quante teste ci sono nel j-esimo iperarco  
                
                y=y+1;
    
            end
    
        end
    
        alfa{j}=ones(o,1)/o;     %%Creo quindi un alfa ed un beta per il j-esimo iperarco che poi conserverò in due matrici dedicate 
        beta{j}=ones(y,1)/y;
    
    end
    
    
    for i=1:N
    
        for j=1:N 
    
            for k=1:n_iperarchi
    
                if mat_e_coda_di(k,j)==j & mat_e_testa_di(k,i)==i
        
                    AL=alfa{k};
                    BET=beta{k};
                    if AL(1)==1 & BET(1)==1
    
                        AL=alfa{k};
                        A(i,j)=A(i,j)+AL(1)*sigma2;
                        AS_piu(i,j)=AS_piu(i,j)+AL(1)*sigma2;
                        AL=[];
    
                    end
                    
                    AL=alfa{k};
                    BET=beta{k};
                    if AL(1)<1 | BET(1)<1
    
                        AL=alfa{k};
                        A(i,j)=A(i,j)+AL(1)*sigma3;
                        AS_piu(i,j)=AS_piu(i,j)+AL(1)*sigma3;
                        AL=[];
    
                    end
        
                end
    
                if mat_e_testa_di(k,j)==j & mat_e_testa_di(k,i)==i
        
%                     AL=alfa{k};
%                     BET=beta{k};
%                     if AL(1)==1 & BET(1)==1
%     
%                         BET=beta{k};
%                         A(i,j)=A(i,j)-BET(1)*sigma2;
%                         BET=[];
%     
%                     end
                    
                    AL=alfa{k};
                    BET=beta{k};
                    if AL(1)<1 | BET(1)<1
    
                        BET=beta{k};
                        A(i,j)=A(i,j)-BET(1)*sigma3;
                        BET=[];
    
                    end
        
                end
    
            end
    
        end
    
    end
    
    for i=1:N
        A(i,i)=0;
    end
    
    %%Recupero il Laplaciano 
    
    L = diag(sum(A,2)) - A;

end