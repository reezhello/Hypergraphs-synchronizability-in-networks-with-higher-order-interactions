clear all 
close all 
clc

n_topologie=100;

%Dati dimensionali del Kuramoto
n=1;
p=1;
gamma=1;
omega_n=2;

%Dati dimensionali della rete desiderata

N=100;
grado_medio_imposto=12;

card=3;
simulazioni_buone=1;

while simulazioni_buone<=n_topologie

    simulazioni_buone

    %Genero la topologia con date caratteristiche

    %Uso questi per modulare il grado medio

         [mat_e_testa_di, mat_e_coda_di]=generatore_ipergrafi_generali_esatti(N,card,grado_medio_imposto);
%         [mat_e_testa_di, mat_e_coda_di]=generatore_ipergrafi_generali_esatti_sink(N,card,grado_medio_imposto(D));
%         [mat_e_testa_di, mat_e_coda_di]=generatore_ipergrafi_generali_esatti_source(N,card,grado_medio_imposto(D));

    %Uso questi per modulare il numero di oggetti 

%         [mat_e_testa_di, mat_e_coda_di]=generatore_ipergrafi_generali_oggetti_imposti(N,card,n_oggetti_imposti(D));
%         [mat_e_testa_di, mat_e_coda_di]=generatore_ipergrafi_generali_oggetti_imposti_sink(N,card,n_oggetti_imposti(D));
%         [mat_e_testa_di, mat_e_coda_di]=generatore_ipergrafi_generali_oggetti_imposti_source(N,card,n_oggetti_imposti(D));

    %Verifico il grado medio della rete generata
    d_out_medio=calcolo_grado_medio(mat_e_coda_di)  
    d_in_medio=calcolo_grado_medio(mat_e_testa_di)

    %Salvataggio dei risultati nella struct
    topologie(simulazioni_buone).grado_medio_out=d_out_medio;
    topologie(simulazioni_buone).grado_medio_in=d_in_medio;
    topologie(simulazioni_buone).simmetria_rete_a_ciclo_aperto=0;
    topologie(simulazioni_buone).numero_nodi=N;
    topologie(simulazioni_buone).card_iperarchi=card;
    topologie(simulazioni_buone).mat_teste=mat_e_testa_di;
    topologie(simulazioni_buone).mat_code=mat_e_coda_di;

    simulazioni_buone=simulazioni_buone+1;

end

%Eventuale comando save 

% save("REV_set_100_top","topologie")
