function [mat_e_testa_di_def, mat_e_coda_di_def] = generatore_ipergrafi_generali_oggetti_imposti_source_card_diver(N, vettore_card)

    mat_e_testa_di=zeros(1,N);
    mat_e_coda_di=zeros(1,N);

    riga=1;
    attivo=1;

    n_cardinalita=size(vettore_card,2);
    numero_oggetti_imposto=sum(vettore_card,2);

    for p=1:n_cardinalita

        u=1;

        while u<=vettore_card(p)
    
            nodi_coinvolti=randperm(N,p);
    
            separatore_teste_code=p-1;
    
            for j=1:p
    
                if j<=separatore_teste_code
    
                    mat_e_testa_di(riga,nodi_coinvolti(j))=nodi_coinvolti(j);
    
                else
    
                    mat_e_coda_di(riga,nodi_coinvolti(j))=nodi_coinvolti(j);
    
                end
    
            end
    
            riga=riga+1;
            u=u+1;
            mat_e_coda_di=[mat_e_coda_di;zeros(1,N)];
            mat_e_testa_di=[mat_e_testa_di;zeros(1,N)];
    
        end

    end

   mat_e_testa_di_def=mat_e_testa_di(1:riga-1,:);
   mat_e_coda_di_def=mat_e_coda_di(1:riga-1,:);

end