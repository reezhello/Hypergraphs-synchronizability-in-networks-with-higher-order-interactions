function [nodo_estratto, indice_nodo_estratto] = estrazione_nodo_preferenziale(nodi_disponibili,vettore_probabilita)

    probabilita_cumulata=zeros(1,size(vettore_probabilita,2));

    for i=1:size(probabilita_cumulata,2)

        probabilita_cumulata(i)=sum(vettore_probabilita(1:i));

    end

    nr=rand;

    probabilita_cumulata=[0 probabilita_cumulata];

    for i=2:size(probabilita_cumulata,2)

        if nr>probabilita_cumulata(i-1) && nr<probabilita_cumulata(i)

            nodo_estratto=nodi_disponibili(i-1);
            indice_nodo_estratto=i-1;
            break

        end

    end

end