function [bound, L_u_bar] = calcolo_bound_kuramoto_sincronizzazione_VELOCE_tetra(n, N, p, omega_n, tra_esplorativa_media_asimmetrica, mat_e_testa_di, mat_e_coda_di, PAR, sigma_v)

    par_nom=omega_n;

    s=tra_esplorativa_media_asimmetrica;

    n_istanti_di_tempo=size(s,1);
    
    f=1;
    Dxf_tv=zeros(n,n,ceil(n_istanti_di_tempo/f));
    massima_parte_reale_autoval_Dxf_tv=zeros(1,ceil(n_istanti_di_tempo)/f);
    Dmuf_tv=zeros(n,p,ceil(n_istanti_di_tempo/f));
    norma_Dx=zeros(ceil(n_istanti_di_tempo/f),1);
    norma_Dmu=zeros(ceil(n_istanti_di_tempo/f),1);
    norma_a=zeros(ceil(n_istanti_di_tempo/f),1);
    Dxh_tv=cos(0)*3;
    prod_kron_H=kron(eye(N-1),Dxh_tv);
    prod_kron_Dxf=zeros((N-1)*n,(N-1)*n,ceil(n_istanti_di_tempo/f));
    parte_reale_massima=zeros(ceil(n_istanti_di_tempo/f),1);
    prod_kron_Dmuf=zeros((N-1)*n,N*p,ceil(n_istanti_di_tempo/f));
    

    [L,~]=adiacenza_e_laplaciano_generali_efficienti(mat_e_testa_di,mat_e_coda_di,N,sigma_v/N);

    vettore_d=zeros(N,1);

    for j=1:N

        vettore_d(j)=mean(L(:,j));

    end

    L_mod=L;

    for j=1:N

        L_mod(:,j)=L_mod(:,j)-vettore_d(j)*ones(N,1);

    end

    B=null(ones(1,N));

    F_inv=[ones(1,N);B'];

    F=inv(F_inv);

    L_disaccopp=F_inv*L_mod*F;
    
    L_rid=L_disaccopp(2:N,2:N);
    
    Sigma=lyap(L_rid',-eye(N-1));    

    L_u_bar=0.5*inv(Sigma);

    L_u_inv=inv(L_u_bar);

    delta_mu=PAR(:)-kron(ones(N,1),par_nom);
    
    for i=1:ceil(n_istanti_di_tempo/f)
        
        Dxf_tv(:,:,i)=0;
        parti_reali_autovalori=real(eig(Dxf_tv(:,:,i)));
        massima_parte_reale_autoval_Dxf_tv(1,i)=max(parti_reali_autovalori);
        Dmuf_tv(:,:,i)=1;
        norma_Dx(i,1)=norm(Dxf_tv(:,:,i));
        norma_Dmu(i,1)=norm(Dmuf_tv(:,:,i));
        prod_kron_Dxf(:,:,i)=kron(L_u_inv,Dxf_tv(:,:,i));
        parte_reale_massima(i)=max(real(eig(prod_kron_Dxf(:,:,i)-prod_kron_H)));
        prod_kron_Dmuf(:,:,i)=kron(L_u_inv*F_inv(2:N,:),Dmuf_tv(:,:,i));
        norma_a(i,1)=norm(kron(L_u_inv*F_inv(2:N,:),Dmuf_tv(:,:,i))*delta_mu);

        
    end
    
    norma_Dx_max=max(norma_Dx);

    a_max=max(norma_a);

    b=max(parte_reale_massima);

    if b>0

        disp('Ipotesi non soddisfatte')
        keyboard

    end

    bound=norm(F)*a_max/(-b);

end