clear all 
close all 
clc 

fo=14;
load("asse_x1_small_top.mat"); %grafo
load("asse_y1_small_top.mat");
t1=t;
ord1=par_ordine;

load("asse_x2_small_top.mat"); %ipergrafo grado
load("asse_y2_small_top.mat");
t2=t;
ord2=par_ordine;

load("asse_x3_small_top.mat"); %ipergrafo benefici
load("asse_y3_small_top.mat");
t3=t;
ord3=par_ordine;

load("asse_x4_small_top.mat"); %ipergrafo malefici
load("asse_y4_small_top.mat");
t4=t;
ord4=par_ordine;

set(groot,'defaultAxesTickLabelInterpreter','latex')
set(groot,'defaultTextInterpreter','latex')
figure
subplot(1,4,1)
plot(t1,ord1(:),'LineWidth',2)
xlabel('$t$')
ylabel('')
% title('Error Vector Norm Temporal Evolution')
xlim([0, 3]);
ylim([0.94 1.03]);
xticks([0 1 2 3])
yticks([0.94 0.97 1 1.03])
ylabel('$R(t)$')
hold on 
plot(t,ones(size(t)),'--r','LineWidth',3)
% legend({'$\|e(t)\|$','$B$'},'Interpreter','latex')
set(gca,'FontSize',fo)

subplot(1,4,4)
plot(t2,ord2(:),'LineWidth',2)
xlabel('$t$')
ylabel('')
% title('Error Vector Norm Temporal Evolution')
xlim([0, 3]);
ylim([0.94 1.03]);
xticks([0 1 2 3])
yticks([0.94 0.97 1 1.03])
hold on 
plot(t,ones(size(t)),'--r','LineWidth',3)
set(gca,'FontSize',fo)

subplot(1,4,2)
plot(t3,ord3(:),'LineWidth',2)
xlabel('$t$')
ylabel('')
% title('Error Vector Norm Temporal Evolution')
xlim([0, 3]);
ylim([0.94 1.03]);
xticks([0 1 2 3])
yticks([0.94 0.97 1 1.03])
hold on 
plot(t,ones(size(t)),'--r','LineWidth',3)
set(gca,'FontSize',fo)

subplot(1,4,3)
plot(t4,ord4(:),'LineWidth',2)
xlabel('$t$')
ylabel('')
% title('Error Vector Norm Temporal Evolution')
xlim([0, 3]);
ylim([0.94 1.03]);
xticks([0 1 2 3])
yticks([0.94 0.97 1 1.03])
hold on 
plot(t,ones(size(t)),'--r','LineWidth',3)

set(gca,'FontSize',fo)
set(gcf, 'Position',  [250, 125, 1200, 250]);