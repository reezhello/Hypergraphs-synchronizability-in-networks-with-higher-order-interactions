clear all 
close all 
clc

n_gruppi=1; 
RISULTATI_FINALI=cell(1,n_gruppi);

load('set_100_top.mat');

n_topologie=100;

%Dati dimensionali del Kuramoto
n=1;
p=1;
gamma=1;
omega_n=0;

%Dati dimensionali della rete desiderata

N=100;
unico_ordine=3;
grado_medio_imposto=12;

sigma=50;
sigma_v=sigma*ones(1,unico_ordine);
norme=[1];

card=3;

for D=1:n_gruppi
    
    %Struct che conterrà i risultati
    
    simulazioni_buone=1;
    
    vettore_bound_effettivi=zeros(n_topologie,1);
    vettore_bound_stimati=zeros(n_topologie,1);

    while simulazioni_buone<=n_topologie

        norma_imposta_di_delta_mu=norme(D);

        % Variazioni parametriche

        delta_mu=randn(1,N);
        
        delta_mu=delta_mu/norm(delta_mu)*norma_imposta_di_delta_mu;
        
        PAR=delta_mu+ones(1,N)*omega_n;
    
        D
        simulazioni_buone
    
        %Genero la topologia con date caratteristiche
    
        mat_e_testa_di=topologie(simulazioni_buone).mat_teste;
        mat_e_coda_di=topologie(simulazioni_buone).mat_code;
    
        %Verifico il grado medio della rete generata
        d_out_medio=calcolo_grado_medio(mat_e_coda_di);  
        d_in_medio=calcolo_grado_medio(mat_e_testa_di);
    
        %Calcolo il numero di iperarchi
    
        n_iperarchi=size(mat_e_testa_di,1);
        
        %Preparo il necessario per la simulazione
        vett_L=vettore_di_laplaciani(mat_e_testa_di, mat_e_coda_di, N, gamma, n, unico_ordine);
        
        %Condizioni iniziali tutte nulle (parto sincronizzato)
        x0=zeros(1,N);
        
        fun = @(t,x) kuramoto_veloce(x, PAR, N, vett_L, n_iperarchi, sigma);
        Tf = 100;
        
        [t, x]=ode23tb(fun,[0 Tf],x0);
    
        tra_media=zeros(size(t,1),n);
    
        for i=1:size(t,1)
    
            for j=1:n
    
                tra_media(i,j)=mean(x(i,j:n:n*N));
    
            end
    
        end
    
        s=tra_media; 
    
        % %Plot traiettorie
        % set(groot,'defaultAxesTickLabelInterpreter','latex')
        % set(groot,'defaultTextInterpreter','latex')
        % figure
        % plot(t,x(:,1:end-1),'LineWidth',1)
        % xlabel('$t$')
        % ylabel('$x_{i}(t)$')
        % 
        % %Plot errore
        % set(groot,'defaultAxesTickLabelInterpreter','latex')
        % set(groot,'defaultTextInterpreter','latex')
        % figure
        % plot(t,x(:,1:end)-s.*ones(1,N(D)),'LineWidth',1)
        % xlabel('$t$')
        % ylabel('$e_{i}(t)$')
            
        norma_err_tv=zeros(1,size(t,1));
        regime_ottenuto=1;
        
        %Calcolo della norma dell'errore
        for u=1:size(t,1)
          
            norma_err_tv(u)=norm(x(u,1:N*n)-kron(ones(1,N),s(u,:)));
           
        end
        
        %Calcolo dell'istante in cui la norma dell'errore ha raggiunto il
        %regime
        for u=2:size(t,1)
        
            if (norma_err_tv(u)-norma_err_tv(u-1))/(t(u)-t(u-1))>=0
        
                regime_ottenuto=u;
                break
        
            end
        
        end
    
        %Stimo il bound usando una stima della traiettoria media
    
        %Calcolo della traiettoria esplorativa (stima della traiettoria
        %media)
    
        x0_esp=0; %Avrei dovuto predere le condizioni iniziali medie, ma la media tra tanti zeri è zero
    
        omega_media=mean(PAR);
    
        fun1 = @(t,x) stima_traiettoria_media_kuramoto(omega_media);
        [~,stima_traiettoria_media]=ode23tb(fun1,[0 Tf],x0_esp);
    
        [bound_stimato, L_u_bar]=calcolo_bound_kuramoto_sincronizzazione_VELOCE(n, N, p, omega_media, stima_traiettoria_media, mat_e_testa_di, mat_e_coda_di, PAR, sigma_v);
        
        condizionamento=cond(L_u_bar);
    
        % %Plot norma errore e bound stimato
        % set(groot,'defaultAxesTickLabelInterpreter','latex')
        % set(groot,'defaultTextInterpreter','latex')
        % figure
        % plot(t,norma_err_tv(:))
        % xlabel('$t$')
        % ylabel('$\|\delta x(t)\|$')
        % title('Error Vector Norm Temporal Evolution')
        % xlim([0, Tf]);
        % ylim([-bound_stimato, 2*bound_stimato]);
        % hold on 
        % plot(t,bound_stimato*ones(size(t)),'--r','LineWidth',2)
        % legend({'$\|\delta x(t)\|$','$B$'},'Interpreter','latex')
    
        %Calcolo del bound effettivo
        bound_effettivo=max(norma_err_tv(regime_ottenuto:end));
    
        %Il bound stimato è rispettato?
        if bound_effettivo<bound_stimato
    
            rispetto_bound_stimato=1;
    
        else
    
            rispetto_bound_stimato=0;
    
        end
    
        vettore_bound_effettivi(simulazioni_buone)=bound_effettivo;
        vettore_bound_stimati(simulazioni_buone)=bound_stimato;
    
        %Salvataggio dei risultati nella struct
        risultati(simulazioni_buone).grado_medio_out=d_out_medio;
        risultati(simulazioni_buone).grado_medio_in=d_in_medio;
        risultati(simulazioni_buone).simmetria_rete_a_ciclo_aperto=0;
        risultati(simulazioni_buone).numero_nodi=N;
        risultati(simulazioni_buone).vettore_sigma=sigma_v;
        risultati(simulazioni_buone).bound_effettivo=bound_effettivo;
        risultati(simulazioni_buone).bound_stimato=bound_stimato;
        risultati(simulazioni_buone).bound_rispettato=rispetto_bound_stimato;
        risultati(simulazioni_buone).norma_mismatch=norme(D);
        risultati(simulazioni_buone).condition_number=condizionamento;
        risultati(simulazioni_buone).card_iperarchi=card;
    
        simulazioni_buone=simulazioni_buone+1;
    
    end

    correlazione_tra_bound=corr(vettore_bound_effettivi,vettore_bound_stimati);
    risultati(1).correlazione_Pearson=correlazione_tra_bound;
    
    correlazione_tra_bound=corr(vettore_bound_effettivi,vettore_bound_stimati,"Type","Kendall");
    risultati(1).correlazione_Kendall=correlazione_tra_bound;
    
    ranking_reale=vettore_ranking(vettore_bound_effettivi');
    risultati(1).classifica_reale=ranking_reale;
    
    ranking_stimato=vettore_ranking(vettore_bound_stimati');
    risultati(1).classifica_stimata=ranking_stimato;
    
    RISULTATI_FINALI{D}=risultati;

end

%Eventuale comando save 

% save("REV_KURAMOTO_MISMATCH","RISULTATI_FINALI")

%Funzioni per usare ode

function xdotF = kuramoto_veloce(x, PAR, N, vett_L, n_iperarchi, sigma)

    xdotF = PAR(1,1:N)'-...
            sum((sigma/N)*sin(pagemtimes(vett_L,pagemtimes(ones(1,1,n_iperarchi),2*x))),3);   %ATTENZIONE è IMPLEMENTATO BENE SOLO PERCHè IL SENO è UNA FUNZIONE DISPARI E VALE CHE SIN(-X)=-SIN(X) idem la tanh
            
end

function xdotF = stima_traiettoria_media_kuramoto(omega_media)

    xdotF = omega_media;

end