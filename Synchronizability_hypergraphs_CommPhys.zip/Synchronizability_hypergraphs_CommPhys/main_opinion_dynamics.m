clear all 
close all 
clc

n_gruppi=1; 
casi=[1];
RISULTATI_FINALI=cell(1,n_gruppi);

n_topologie=1;

%Dati dimensionali del Kuramoto
n=1;
p=2;
a_n=3;
b_n=2;

par_nom=[a_n b_n];

%Dati dimensionali della rete desiderata

N=1000;
card=3;
grado_medio_imposto=8;
dimensioni_caste=10;
sigma=10;
sigma_v=sigma*ones(1,card);
gamma=1;
n_iperarchi_da_aggiungere=20;

for D=1:n_gruppi

load('par_opinion_dynamics.mat')
PAR=delta_mu+kron(ones(1,N),par_nom');

%Struct che conterrà i risultati

risultati(10*n_topologie)=struct('simmetria_rete_a_ciclo_aperto',[],'numero_nodi',[],'card_iperarchi',[],'grado_medio_in',[],'grado_medio_out',[],'vettore_sigma',[],'bound_stimato',[],'condition_number',[],'caso',[],'classifica_stimata',[]);
simulazioni_buone=1;

% vettore_bound_effettivi=zeros(n_topologie,1);
vettore_bound_stimati=zeros(n_topologie,1);

while simulazioni_buone<=n_topologie

    D
    simulazioni_buone

    %Genero la topologia con date caratteristiche

    load('heads_opinion_dynamics.mat')
    load('tails_opinion_dynamics.mat')
    
    %Verifico il grado medio della rete generata
    d_out_medio=calcolo_grado_medio(mat_e_coda_di)  
    d_in_medio=calcolo_grado_medio(mat_e_testa_di)

    %Calcolo il numero di iperarchi

    n_iperarchi=size(mat_e_testa_di,1);

    %Calcolo il vettore degli overall_degree

    deg_out=calcolo_gradi(mat_e_coda_di);
    deg_in=calcolo_gradi(mat_e_testa_di);

    overall_deg=(deg_out+deg_in)/2;

    [gradi_massimi, nodi_influencers]=maxk(overall_deg, dimensioni_caste);
    [gradi_minimi, nodi_emarginati]=mink(overall_deg, dimensioni_caste);

    caso=casi(D);

    switch caso

        case 1  %emarginati parlano fra loro con sink

            while 1

                pezzo_code=zeros(n_iperarchi_da_aggiungere,N);
                pezzo_teste=zeros(n_iperarchi_da_aggiungere,N);

                for hyp=1:n_iperarchi_da_aggiungere
    
                    indici_nodi_emarginati_coinvolti=randperm(dimensioni_caste,card);
                    
                    pezzo_code(hyp,nodi_emarginati(indici_nodi_emarginati_coinvolti(1)))=nodi_emarginati(indici_nodi_emarginati_coinvolti(1));
                    pezzo_code(hyp,nodi_emarginati(indici_nodi_emarginati_coinvolti(2)))=nodi_emarginati(indici_nodi_emarginati_coinvolti(2));
                    pezzo_teste(hyp,nodi_emarginati(indici_nodi_emarginati_coinvolti(3)))=nodi_emarginati(indici_nodi_emarginati_coinvolti(3));
    
                end

                pezzo_complessivo_norip=unique([pezzo_code pezzo_teste],"rows","stable");

                if size(pezzo_complessivo_norip,1)==n_iperarchi_da_aggiungere

                    break

                end

            end

        case 2  %influencers parlano fra loro con sink 

            while 1

                pezzo_code=zeros(n_iperarchi_da_aggiungere,N);
                pezzo_teste=zeros(n_iperarchi_da_aggiungere,N);

                for hyp=1:n_iperarchi_da_aggiungere
    
                    indici_nodi_influencers_coinvolti=randperm(dimensioni_caste,card);
                    
                    pezzo_code(hyp,nodi_influencers(indici_nodi_influencers_coinvolti(1)))=nodi_influencers(indici_nodi_influencers_coinvolti(1));
                    pezzo_code(hyp,nodi_influencers(indici_nodi_influencers_coinvolti(2)))=nodi_influencers(indici_nodi_influencers_coinvolti(2));
                    pezzo_teste(hyp,nodi_influencers(indici_nodi_influencers_coinvolti(3)))=nodi_influencers(indici_nodi_influencers_coinvolti(3));
    
                end

                pezzo_complessivo_norip=unique([pezzo_code pezzo_teste],"rows","stable");

                if size(pezzo_complessivo_norip,1)==n_iperarchi_da_aggiungere

                    break

                end

            end

        case 3  %influencers parlano con emarginati con sink 

            while 1

                pezzo_code=zeros(n_iperarchi_da_aggiungere,N);
                pezzo_teste=zeros(n_iperarchi_da_aggiungere,N);

                for hyp=1:n_iperarchi_da_aggiungere
        
                    indici_nodi_influencers_coinvolti=randperm(dimensioni_caste,card-1);
                    indici_nodi_emarginati_coinvolti=randperm(dimensioni_caste,1);
                    
                    pezzo_code(hyp,nodi_influencers(indici_nodi_influencers_coinvolti(1)))=nodi_influencers(indici_nodi_influencers_coinvolti(1));
                    pezzo_code(hyp,nodi_influencers(indici_nodi_influencers_coinvolti(2)))=nodi_influencers(indici_nodi_influencers_coinvolti(2));
                    pezzo_teste(hyp,nodi_emarginati(indici_nodi_emarginati_coinvolti(1)))=nodi_emarginati(indici_nodi_emarginati_coinvolti(1));
        
                end

                pezzo_complessivo_norip=unique([pezzo_code pezzo_teste],"rows","stable");

                if size(pezzo_complessivo_norip,1)==n_iperarchi_da_aggiungere

                    break

                end

            end

        case 4  %emarginati parlano con influencers con sink 

            while 1

                pezzo_code=zeros(n_iperarchi_da_aggiungere,N);
                pezzo_teste=zeros(n_iperarchi_da_aggiungere,N);

                for hyp=1:n_iperarchi_da_aggiungere
        
                    indici_nodi_influencers_coinvolti=randperm(dimensioni_caste,1);
                    indici_nodi_emarginati_coinvolti=randperm(dimensioni_caste,card-1);
                    
                    pezzo_code(hyp,nodi_emarginati(indici_nodi_emarginati_coinvolti(1)))=nodi_emarginati(indici_nodi_emarginati_coinvolti(1));
                    pezzo_code(hyp,nodi_emarginati(indici_nodi_emarginati_coinvolti(2)))=nodi_emarginati(indici_nodi_emarginati_coinvolti(2));
                    pezzo_teste(hyp,nodi_influencers(indici_nodi_influencers_coinvolti(1)))=nodi_influencers(indici_nodi_influencers_coinvolti(1));
        
                end

                pezzo_complessivo_norip=unique([pezzo_code pezzo_teste],"rows","stable");

                if size(pezzo_complessivo_norip,1)==n_iperarchi_da_aggiungere

                    break

                end

            end

        %Source

        case 5  %emarginati parlano fra loro con source

            while 1

                pezzo_code=zeros(n_iperarchi_da_aggiungere,N);
                pezzo_teste=zeros(n_iperarchi_da_aggiungere,N);

                for hyp=1:n_iperarchi_da_aggiungere
    
                    indici_nodi_emarginati_coinvolti=randperm(dimensioni_caste,card);
                    
                    pezzo_teste(hyp,nodi_emarginati(indici_nodi_emarginati_coinvolti(1)))=nodi_emarginati(indici_nodi_emarginati_coinvolti(1));
                    pezzo_teste(hyp,nodi_emarginati(indici_nodi_emarginati_coinvolti(2)))=nodi_emarginati(indici_nodi_emarginati_coinvolti(2));
                    pezzo_code(hyp,nodi_emarginati(indici_nodi_emarginati_coinvolti(3)))=nodi_emarginati(indici_nodi_emarginati_coinvolti(3));
    
                end

                pezzo_complessivo_norip=unique([pezzo_code pezzo_teste],"rows","stable");

                if size(pezzo_complessivo_norip,1)==n_iperarchi_da_aggiungere

                    break

                end

            end

        case 6  %influencers parlano fra loro con source

            while 1

                pezzo_code=zeros(n_iperarchi_da_aggiungere,N);
                pezzo_teste=zeros(n_iperarchi_da_aggiungere,N);

                for hyp=1:n_iperarchi_da_aggiungere
    
                    indici_nodi_influencers_coinvolti=randperm(dimensioni_caste,card);
                    
                    pezzo_teste(hyp,nodi_influencers(indici_nodi_influencers_coinvolti(1)))=nodi_influencers(indici_nodi_influencers_coinvolti(1));
                    pezzo_teste(hyp,nodi_influencers(indici_nodi_influencers_coinvolti(2)))=nodi_influencers(indici_nodi_influencers_coinvolti(2));
                    pezzo_code(hyp,nodi_influencers(indici_nodi_influencers_coinvolti(3)))=nodi_influencers(indici_nodi_influencers_coinvolti(3));
    
                end

                pezzo_complessivo_norip=unique([pezzo_code pezzo_teste],"rows","stable");

                if size(pezzo_complessivo_norip,1)==n_iperarchi_da_aggiungere

                    break

                end

            end

        case 7  %influencers parlano con emarginati con source 

            while 1

                pezzo_code=zeros(n_iperarchi_da_aggiungere,N);
                pezzo_teste=zeros(n_iperarchi_da_aggiungere,N);

                for hyp=1:n_iperarchi_da_aggiungere
        
                    indici_nodi_influencers_coinvolti=randperm(dimensioni_caste,1);
                    indici_nodi_emarginati_coinvolti=randperm(dimensioni_caste,card-1);
                    
                    pezzo_code(hyp,nodi_influencers(indici_nodi_influencers_coinvolti(1)))=nodi_influencers(indici_nodi_influencers_coinvolti(1));
                    pezzo_teste(hyp,nodi_emarginati(indici_nodi_emarginati_coinvolti(2)))=nodi_emarginati(indici_nodi_emarginati_coinvolti(2));
                    pezzo_teste(hyp,nodi_emarginati(indici_nodi_emarginati_coinvolti(1)))=nodi_emarginati(indici_nodi_emarginati_coinvolti(1));
        
                end

                pezzo_complessivo_norip=unique([pezzo_code pezzo_teste],"rows","stable");

                if size(pezzo_complessivo_norip,1)==n_iperarchi_da_aggiungere

                    break

                end

            end

        case 8  %emarginati parlano con influencers con source

            while 1

                pezzo_code=zeros(n_iperarchi_da_aggiungere,N);
                pezzo_teste=zeros(n_iperarchi_da_aggiungere,N);

                for hyp=1:n_iperarchi_da_aggiungere
        
                    indici_nodi_influencers_coinvolti=randperm(dimensioni_caste,card-1);
                    indici_nodi_emarginati_coinvolti=randperm(dimensioni_caste,1);
                    
                    pezzo_code(hyp,nodi_emarginati(indici_nodi_emarginati_coinvolti(1)))=nodi_emarginati(indici_nodi_emarginati_coinvolti(1));
                    pezzo_teste(hyp,nodi_influencers(indici_nodi_influencers_coinvolti(2)))=nodi_influencers(indici_nodi_influencers_coinvolti(2));
                    pezzo_teste(hyp,nodi_influencers(indici_nodi_influencers_coinvolti(1)))=nodi_influencers(indici_nodi_influencers_coinvolti(1));
        
                end

                pezzo_complessivo_norip=unique([pezzo_code pezzo_teste],"rows","stable");

                if size(pezzo_complessivo_norip,1)==n_iperarchi_da_aggiungere

                    break

                end

            end

    end

    mat_e_testa_di=[mat_e_testa_di; pezzo_teste];
    mat_e_coda_di=[mat_e_coda_di; pezzo_code];
    
    %Condizioni iniziali 
     load('x0_opinion_dynamics.mat')

    %Calcolo della traiettoria esplorativa (stima della traiettoria
    %media)

    x0_esp=mean(x0); %Avrei dovuto predere le condizioni iniziali medie, ma la media tra tanti zeri è zero

    par_medi=mean(PAR,2);

    Tf=100;

    fun1 = @(t,x) stima_traiettoria_media_leonard(x, par_medi(1), par_medi(2));
    [~,stima_traiettoria_media]=ode23tb(fun1,[0 Tf],x0_esp);

    [bound_stimato,L_u_bar]=calcolo_bound_leonard_effective_resistance(n,N,p,par_medi, stima_traiettoria_media, mat_e_testa_di, mat_e_coda_di, PAR, sigma_v);

    condizionamento=cond(L_u_bar);

    vettore_bound_stimati(simulazioni_buone)=bound_stimato;

    %Salvataggio dei risultati nella struct
    risultati(simulazioni_buone).grado_medio_out=d_out_medio;
    risultati(simulazioni_buone).grado_medio_in=d_in_medio;
    risultati(simulazioni_buone).simmetria_rete_a_ciclo_aperto=0;
    risultati(simulazioni_buone).numero_nodi=N;
    risultati(simulazioni_buone).vettore_sigma=sigma_v;
    risultati(simulazioni_buone).bound_stimato=bound_stimato;
    risultati(simulazioni_buone).condition_number=condizionamento;
    risultati(simulazioni_buone).card_iperarchi=card;
    risultati(simulazioni_buone).caso=caso;

    simulazioni_buone=simulazioni_buone+1;

end

ranking_stimato=vettore_ranking(vettore_bound_stimati');
risultati(1).classifica_stimata=ranking_stimato;

for z=1:10*n_topologie

    if isempty(risultati(z).condition_number)==1

        indice_vuoto=z;
        break

    end

end

risultati=risultati(1:indice_vuoto-1);

RISULTATI_FINALI{D}=risultati;

end

%Eventuale comando save 

%save("ipergrafi_source_oggetti_800_1000_1400_1600_kur_ER_100top_eps1","RISULTATI_FINALI")

%Funzioni per usare ode

function xdotF = stima_traiettoria_media_leonard(x, a_n, b_n)

    xdotF = -a_n*x+b_n;

end
