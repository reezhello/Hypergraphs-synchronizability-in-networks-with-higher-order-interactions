function tbl_risultati = games_howell(valori, gruppi)
    % GAMES_HOWELL Specifica per vettori paralleli con etichette testuali personalizzate
    
    valori = valori(:);
    gruppi = gruppi(:);
    
    nomi_reali = {'Grafi', 'Ipergrafi', 'Malefici', 'Benefici'};
    nomi_gruppi = unique(gruppi);
    k = length(nomi_gruppi);
    num_confronti = nchoosek(k, 2);
    
    G1 = cell(num_confronti, 1); G2 = cell(num_confronti, 1);
    DiffMean = zeros(num_confronti, 1); T_Stat = zeros(num_confronti, 1); P_Adj = zeros(num_confronti, 1);
    
    N = zeros(k,1); Mean = zeros(k,1); Var = zeros(k,1);
    for i = 1:k
        idx = (gruppi == nomi_gruppi(i));
        dati_g = valori(idx);
        N(i) = length(dati_g); Mean(i) = mean(dati_g); Var(i) = var(dati_g);
    end
    
    contatore = 1;
    for i = 1:k
        for j = i+1:k
            G1{contatore} = nomi_reali{nomi_gruppi(i)};
            G2{contatore} = nomi_reali{nomi_gruppi(j)};
            
            DiffMean(contatore) = Mean(i) - Mean(j);
            se = sqrt(Var(i)/N(i) + Var(j)/N(j));
            df_coppia = (Var(i)/N(i) + Var(j)/N(j))^2 / ...
                        ( (Var(i)/N(i))^2/(N(i)-1) + (Var(j)/N(j))^2/(N(j)-1) );
            
            T_Stat(contatore) = abs(DiffMean(contatore)) / se;
            p_raw = 2 * (1 - tcdf(T_Stat(contatore), df_coppia));
            P_Adj(contatore) = min(1, p_raw * num_confronti);
            
            contatore = contatore + 1;
        end
    end

    tbl_risultati = table(G1, G2, DiffMean, T_Stat, P_Adj, ...
        'VariableNames', {'Modello_1', 'Modello_2', 'Diff_Medie', 'Stat_t', 'p_value_corr'});
end