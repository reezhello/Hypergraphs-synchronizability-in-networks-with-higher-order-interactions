clear all 
close all
clc

o=i;
psi=0.1;

n=1;
N=5;

forte_connessione_ol=0;  %Salvo se il grafo a ciclo aperto è fortemente connesso
debole_connessione_ol=0;  %Salvo se il grafo a ciclo aperto è debolmente connesso
rispetto_bound=0;

p=1;
sigma2=10;
sigma3=sigma2;
gamma=1;
simulazioni_buone=1;

norma_massima_finale_simulazioni=0;
media_finale_simulazioni=0;
deltax_finale_simulazioni=0;

% metti le mat relative alla topologia
% card=2;
%mat_e_testa_di=[0 0 3 0 0; 0 0 0 4 0; 0 2 0 0 0; 1 0 0 0 0; 0 2 0 0 0; 0 0 0 4 0]; % grafo
%mat_e_coda_di= [1 0 0 0 0; 1 0 0 0 0; 0 0 3 0 0; 0 0 0 0 5; 0 0 0 4 0; 0 2 0 0 0];

% ipergrafo stesso grado medio (peggio del grafo)
card=3;
mat_e_testa_di=[1 2 0 0 0; 0 0 0 4 0; 0 0 3 0 0; 0 2 0 0 5]; 
mat_e_coda_di=[0 0 3 0 0; 1 2 0 0 0; 1 0 0 0 5; 0 0 0 4 0];
  
% ipergrafo stessi oggetti (meglio del grafo)
% card=3;
% mat_e_testa_di=[1 0 0 0 0; 0 2 0 0 0; 0 0 3 0 0; 0 0 0 4 0; 0 0 0 4 0; 0 0 0 0 5]; 
% mat_e_coda_di= [0 2 0 0 5; 0 0 0 4 5; 0 0 0 4 5; 1 2 0 0 0; 1 0 3 0 0; 1 0 3 0 0];

% ipergrafo stessi oggetti (peggio del grafo)
% card=3;
% mat_e_testa_di=[0 2 0 0 5; 0 0 0 4 5; 0 0 0 4 5; 1 2 0 0 0; 1 0 3 0 0; 1 0 3 0 0]; 
% mat_e_coda_di= [1 0 0 0 0; 0 2 0 0 0; 0 0 3 0 0; 0 0 0 4 0; 0 0 0 4 0; 0 0 0 0 5];

n_iperarchi=size(mat_e_coda_di,1);

d_out_medio_ol_TOTALE=calcolo_grado_medio(mat_e_coda_di);  
d_in_medio_ol_TOTALE=calcolo_grado_medio(mat_e_testa_di);

mat_e_coda_di_ol=mat_e_coda_di;
mat_e_testa_di_ol=mat_e_testa_di;    

[L_open_loop, A_open_loop, AS_piu_open_loop]=adiacenza_e_laplaciano(mat_e_testa_di,mat_e_coda_di, N, n_iperarchi, sigma2, sigma3);

vett_L=vettore_di_laplaciani(mat_e_testa_di, mat_e_coda_di, N, gamma, n, card);

GS_piu_open_loop=digraph(AS_piu_open_loop);
CS_piu_open_loop=condensation(GS_piu_open_loop);
bins_ol=conncomp(GS_piu_open_loop);
weak_bins_ol=conncomp(GS_piu_open_loop,'Type','weak');

if bins_ol==ones(1,N)

    forte_connessione_ol=1;

end

if weak_bins_ol==ones(1,N)

    debole_connessione_ol=1;

end

% Parametri Nominali 
omega_n = 2;

par_nom=omega_n;

%Differenze Parametriche
min_err=1-psi;  
max_err=1+psi;
PAR=zeros(p,N);

for i=1:N

    for j=1:p
    
        PAR(j,i)=2*psi*par_nom(j)*rand+par_nom(j)-psi*par_nom(j);

    end
    
end 

omega_media=mean(PAR);

%Condizioni Iniziali
x0_n=0;
c_i=zeros(1,N);
scos=3;

for d=1:N

    c_i(d)=unifrnd(x0_n-pi/scos, x0_n+pi/scos);

end

x0=c_i;

x0=x0(1:n*N);

fun = @(t,x) kuramoto(x, PAR, sigma2, sigma3, N, n, mat_e_testa_di, mat_e_coda_di);
fun1 = @(t,x) kuramoto_veloce(x, PAR, N, vett_L, n_iperarchi, sigma2);
fun2 = @(t,x) kuramoto_uguali(x, omega_n, N, vett_L ,n_iperarchi, sigma2);
Tf = 20;

[t, x]=ode45(fun1,[0 Tf],x0);

tra_media=zeros(size(t,1),n);

for i=1:size(t,1)

    for j=1:n

        tra_media(i,j)=mean(x(i,j:n:n*N));

    end

end

s=tra_media;
    
norma_err_tv=zeros(1,size(t,1));
regime_ottenuto=1;

for u=1:size(t,1)
  
    norma_err_tv(u)=norm(x(u,1:N*n)-kron(ones(1,N),s(u,:)));
   
end
    
for u=2:size(t,1)

    if (norma_err_tv(u)-norma_err_tv(u-1))/(t(u)-t(u-1))>=0

        regime_ottenuto=u;
        break

    end

end

x0_esp=0;
fun4 = @(t,x) stima_traiettoria_media_kuramoto(omega_media);
[~,stima_traiettoria_media]=ode45(fun4,[0 Tf],x0_esp);

bound_effettivo=norma_err_tv(end);

par_ordine=zeros(1,size(t,1));

for i=1:size(t,1)

    par_ordine(i)=abs(1/N*sum(exp(x(i,:)*o)));

end

set(groot,'defaultAxesTickLabelInterpreter','latex')
set(groot,'defaultTextInterpreter','latex')
figure
plot(t,par_ordine(:))
xlabel('$t$')
ylabel('$R(t)$')
title('Order parameter temporal evolution')
xlim([0, 3]);
ylim([0.94, 1.03]);
yticks([0.94 0.97 1 1.03])
hold on 
plot(t,par_ordine(end)*ones(size(t,1)),'--r','LineWidth',1)
hold on 
plot(t,ones(size(t,1)),'k','LineWidth',1)


%% Functions

function xdotF = kuramoto(x, PAR, sigma2, sigma3, N, n, mat_e_testa_di, mat_e_coda_di)

    xdotF = PAR(1,1:N)'+...
            contributo_iperarchi_tesi_kuramoto(mat_e_testa_di,mat_e_coda_di,n,N,x,sigma2,sigma3);
            
end

function xdotF = kuramoto_veloce(x, PAR, N, vett_L, n_iperarchi, sigma)

    xdotF = PAR(1,1:N)'-...
            sum((sigma/N)*sin(pagemtimes(vett_L,pagemtimes(ones(1,1,n_iperarchi),2*x))),3);
            
end

function xdotF = kuramoto_uguali(x, omega_n, N, vett_L, n_iperarchi, sigma)

    xdotF = omega_n*ones(N,1) -...
            sum((sigma/N)*sin(pagemtimes(vett_L,pagemtimes(ones(1,1,n_iperarchi),2*x))),3);
            
end

function xdotF = stima_traiettoria_media_kuramoto(omega_media)

    xdotF = omega_media;

end