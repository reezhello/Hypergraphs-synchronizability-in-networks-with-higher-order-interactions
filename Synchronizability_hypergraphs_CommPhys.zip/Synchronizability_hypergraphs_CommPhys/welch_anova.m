function [p_value, F_stat, df1, df2] = welch_anova(valori, gruppi)
    % WELCH_ANOVA Specifica per vettori paralleli (Grafi, Ipergrafi, Malefici, Benefici)
    
    % Forza i vettori ad essere colonne per i calcoli matriciali
    valori = valori(:);
    gruppi = gruppi(:);
    
    nomi_gruppi = unique(gruppi);
    k = length(nomi_gruppi);
    
    N = zeros(k,1); Mean = zeros(k,1); Var = zeros(k,1); W = zeros(k,1);
    
    for i = 1:k
        idx = (gruppi == nomi_gruppi(i));
        dati_g = valori(idx);
        N(i) = length(dati_g);
        Mean(i) = mean(dati_g);
        Var(i) = var(dati_g);
        W(i) = N(i) / Var(i); % Peso di Welch
    end
    
    W_tot = sum(W);
    grand_mean_w = sum(W .* Mean) / W_tot;
    
    num_F = sum(W .* (Mean - grand_mean_w).^2) / (k - 1);
    den_term = sum((1 - W / W_tot).^2 ./ (N - 1));
    
    F_stat = num_F / (1 + (2 * (k - 2) / (k^2 - 1)) * den_term);
    df1 = k - 1;
    df2 = 1 / ( (3 / (k^2 - 1)) * den_term );
    
    p_value = 1 - fcdf(F_stat, df1, df2);
end