function vett_rank = vettore_ranking(vettore_riga)

    copia=vettore_riga;
    vett_rank=zeros(1,size(copia,2));

    for i=1:size(copia,2)

        [~, index_min]=min(copia);
        vett_rank(index_min)=i;
        copia(index_min)=10000;

    end

end