clear all 
close all 
clc

load('gra_deg_cresc_connectivity_issue.mat')
GRAFI=RISULTATI_FINALI;
load('hyp_deg_cresc_connectivity_issue.mat')
IPERGRAFI=RISULTATI_FINALI;
load('hyp_deg_cresc_source_connectivity_issue.mat')
MALEFICI=RISULTATI_FINALI;
load('hyp_deg_cresc_sink_connectivity_issue.mat')
BENEFICI=RISULTATI_FINALI;

set(groot,'defaultAxesTickLabelInterpreter','latex')
set(groot,'defaultTextInterpreter','latex')
fs=15;

n_topologie=100;
n_gradi=5;

n_asincroni_grafi=zeros(1,n_gradi);
n_asincroni_ipergrafi=zeros(1,n_gradi);
n_asincroni_malefici=zeros(1,n_gradi);
n_asincroni_benefici=zeros(1,n_gradi);

for G=1:n_gradi

    gruppo_grafi=GRAFI{G};
    gruppo_ipergrafi=IPERGRAFI{G};
    gruppo_malefici=MALEFICI{G};
    gruppo_benefici=BENEFICI{G};

    for i=1:n_topologie

        %Grafi
        aut_piccoli=gruppo_grafi(i).autovalori_piu_piccoli;
        aut_minimo=min(aut_piccoli);

        if aut_minimo<1e-7

            n_asincroni_grafi(1,G)=n_asincroni_grafi(1,G)+1;

        end

        %Ipergrafi
        aut_piccoli=gruppo_ipergrafi(i).autovalori_piu_piccoli;
        aut_minimo=min(aut_piccoli);

        if aut_minimo<1e-7

            n_asincroni_ipergrafi(1,G)=n_asincroni_ipergrafi(1,G)+1;

        end

        %Malefici
        aut_piccoli=gruppo_malefici(i).autovalori_piu_piccoli;
        aut_minimo=min(aut_piccoli);

        if aut_minimo<1e-7

            n_asincroni_malefici(1,G)=n_asincroni_malefici(1,G)+1;

        end

        %Benefici
        aut_piccoli=gruppo_benefici(i).autovalori_piu_piccoli;
        aut_minimo=min(aut_piccoli);

        if aut_minimo<1e-5

            n_asincroni_benefici(1,G)=n_asincroni_benefici(1,G)+1;

        end

    end

end

%Normalizzo
n_asincroni_grafi=n_asincroni_grafi/n_topologie;
n_asincroni_ipergrafi=n_asincroni_ipergrafi/n_topologie;
n_asincroni_malefici=n_asincroni_malefici/n_topologie;
n_asincroni_benefici=n_asincroni_benefici/n_topologie;

n_tuttok_grafi=ones(1,n_gradi)-n_asincroni_grafi;
n_tuttok_ipergrafi=ones(1,n_gradi)-n_asincroni_ipergrafi;
n_tuttok_malefici=ones(1,n_gradi)-n_asincroni_malefici;
n_tuttok_benefici=ones(1,n_gradi)-n_asincroni_benefici;

vettore_asse_x=[1 2 3 4 5];

figure
plot(vettore_asse_x,n_tuttok_grafi,'Color','k','LineWidth',1.5,'Marker','o','MarkerFaceColor','k','MarkerSize',4)
hold on
plot(vettore_asse_x,n_tuttok_ipergrafi,'Color',[0 143 57]/255,'LineWidth',1.5,'Marker','o','MarkerFaceColor',[0 143 57]/255,'MarkerSize',4)
hold on
plot(vettore_asse_x,n_tuttok_malefici,'Color','b','LineWidth',1.5,'Marker','o','MarkerFaceColor','b','MarkerSize',4)
hold on
plot([vettore_asse_x],n_tuttok_benefici,'Color','r','LineWidth',1.5,'Marker','o','MarkerFaceColor','r','MarkerSize',4)
hold on 
plot([0 vettore_asse_x 6],ones(1,size(vettore_asse_x,2)+2),'Color',[0.5 0.5 0.5],'LineWidth',1,'LineStyle','--')

xticks([0 1 2 3 4 5 6])
xticklabels([2 4 6 8 10 12 14])
yticks([0 0.33 0.66 1])
limx=[0 6];
xlim(limx)
limy=[0 1.2];
ylim(limy)
xlabel("$\overline k$")
legend({'Digraphs','ER hypergraphs','Source hypergraphs','Sink hypergraphs'},'Interpreter','latex','Location','southeast','FontSize',9)
set(gca,'FontSize',fs)

set(gcf, 'Position',  [250, 125, 625, 300]);

% h=gcf;
% set(h,'Units','Inches');
% pos = get(h,'Position');
% set(h,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])
% print(h,'FIGURA_DOPPI_ZERI','-dpdf','-r0')