clear all 
close all 
clc

n_topologie_gruppo=100;
n_gruppi=5;

load("hyp_kur_mismatch_cresc.mat");
KUR=RISULTATI_FINALI;
load("hyp_ross_mismatch_cresc.mat")
ROSS=RISULTATI_FINALI;

set(groot,'defaultAxesTickLabelInterpreter','latex')
set(groot,'defaultTextInterpreter','latex')

matrice_stim_kur=zeros(n_topologie_gruppo,n_gruppi);
matrice_eff_kur=zeros(n_topologie_gruppo,n_gruppi);

matrice_stim_ross=zeros(n_topologie_gruppo,n_gruppi);
matrice_eff_ross=zeros(n_topologie_gruppo,n_gruppi);

matrice_S_kur=zeros(n_topologie_gruppo,n_gruppi);
matrice_S_ross=zeros(n_topologie_gruppo,n_gruppi);

quante_reti_non_sincronizzano_K=zeros(1,n_gruppi);
quante_reti_non_sincronizzano_R=zeros(1,n_gruppi);
quante_hp_insoddisfatte_R=zeros(1,n_gruppi);

for j=1:n_gruppi

    gruppo=KUR{j};

    for i=1:n_topologie_gruppo
    
        matrice_eff_kur(i,j)=gruppo(i).bound_effettivo;
        matrice_stim_kur(i,j)=gruppo(i).bound_stimato;
        matrice_S_kur(i,j)=(gruppo(i).bound_stimato/sqrt(gruppo(i).numero_nodi))^(-1);

        if matrice_eff_kur(i,j)>3 

            quante_reti_non_sincronizzano_K(j)=quante_reti_non_sincronizzano_K(j)+1;

        end

        if matrice_eff_kur(i,j)>3 && j<n_gruppi

            matrice_eff_kur(i,j)=NaN;
            matrice_stim_kur(i,j)=NaN;
            matrice_S_kur(i,j)=NaN;

        end
    
    end

end

for j=1:n_gruppi

    gruppo=ROSS{j};

    for i=1:n_topologie_gruppo
    
        matrice_eff_ross(i,j)=gruppo(i).bound_effettivo;
        matrice_stim_ross(i,j)=gruppo(i).bound_stimato;
        matrice_S_ross(i,j)=(gruppo(i).bound_stimato/sqrt(gruppo(i).numero_nodi))^(-1);


        if matrice_eff_ross(i,j)>3

            quante_reti_non_sincronizzano_R(j)=quante_reti_non_sincronizzano_R(j)+1;

            matrice_eff_ross(i,j)=NaN;
            matrice_stim_ross(i,j)=NaN;
            matrice_S_ross(i,j)=NaN;

        end

        if matrice_stim_ross(i,j)<0

            quante_hp_insoddisfatte_R(j)=quante_hp_insoddisfatte_R(j)+1;

            matrice_eff_ross(i,j)=NaN;
            matrice_stim_ross(i,j)=NaN;
            matrice_S_kur(i,j)=NaN;

        end
    
    end

end

set(groot,'defaultAxesTickLabelInterpreter','latex')
set(groot,'defaultTextInterpreter','latex')

vettore_pearson_K=zeros(1,n_gruppi);
vettore_kendall_K=zeros(1,n_gruppi);
vettore_rquadro_K=zeros(1,n_gruppi);
vettore_S_mean_K=zeros(1,n_gruppi);
vettore_S_std_K=zeros(1,n_gruppi);
matrice_parametri_K=zeros(2,n_gruppi);

vettore_pearson_R=zeros(1,n_gruppi);
vettore_kendall_R=zeros(1,n_gruppi);
vettore_rquadro_R=zeros(1,n_gruppi);
vettore_S_mean_R=zeros(1,n_gruppi);
vettore_S_std_R=zeros(1,n_gruppi);
matrice_parametri_R=zeros(2,n_gruppi);

for i=1:n_gruppi

    vettore_stim=matrice_stim_kur(:,i);
    vettore_eff=matrice_eff_kur(:,i);
    vettore_S=matrice_S_kur(:,i);

    vettore_stim=vettore_stim(~isnan(vettore_stim));
    vettore_eff=vettore_eff(~isnan(vettore_eff));
    vettore_S=vettore_S(~isnan(vettore_S));


    mdl_kur=fitlm(vettore_eff,vettore_stim); %Correlazioni "a pezzi"
    vettore_pearson_K(i)=corr(vettore_eff,vettore_stim);
    vettore_kendall_K(i)=corr(vettore_eff,vettore_stim,"Type","Kendall");
    vettore_rquadro_K(i)=mdl_kur.Rsquared.Ordinary;
    matrice_parametri_K(:,i)=mdl_kur.Coefficients.Estimate;

    vettore_S_mean_K(i)=mean(vettore_S);
    vettore_S_std_K(i)=std(vettore_S);

end

for i=1:n_gruppi

    vettore_stim=matrice_stim_ross(:,i);
    vettore_eff=matrice_eff_ross(:,i);
    vettore_S=matrice_S_ross(:,i);

    vettore_stim=vettore_stim(~isnan(vettore_stim));
    vettore_eff=vettore_eff(~isnan(vettore_eff));
    vettore_S=vettore_S(~isnan(vettore_S));


    mdl_ross=fitlm(vettore_eff,vettore_stim); %Correlazioni "a pezzi"
    vettore_pearson_R(i)=corr(vettore_eff,vettore_stim);
    vettore_kendall_R(i)=corr(vettore_eff,vettore_stim,"Type","Kendall");
    vettore_rquadro_R(i)=mdl_ross.Rsquared.Ordinary;
    matrice_parametri_R(:,i)=mdl_ross.Coefficients.Estimate;

    vettore_S_mean_R(i)=mean(vettore_S);
    vettore_S_std_R(i)=std(vettore_S);

end

tab_K=[vettore_S_mean_K; vettore_S_std_K; vettore_pearson_K; vettore_kendall_K; vettore_rquadro_K];
tab_R=[vettore_S_mean_R; vettore_S_std_R; vettore_pearson_R; vettore_kendall_R; vettore_rquadro_R];


