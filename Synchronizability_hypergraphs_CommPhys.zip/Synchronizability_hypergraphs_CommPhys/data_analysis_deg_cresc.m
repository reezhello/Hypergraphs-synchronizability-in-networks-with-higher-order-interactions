clear all 
close all 
clc

set(groot,'defaultAxesTickLabelInterpreter','latex')
set(groot,'defaultTextInterpreter','latex')

k=5;
kk=k;


load('gra_deg_cresc_kur_100top_eps1_v2.mat')
GRA_KUR=RISULTATI_FINALI;
load('hyp_deg_cresc_kur_100top_esp1_v2.mat')
IPER_KUR=RISULTATI_FINALI;
load('hyp_deg_cresc_source_kur_100top_eps1_v2.mat')
IPER_KUR_MAL=RISULTATI_FINALI;
load('hyp_deg_cresc_sink_kur_100top_eps1_v2.mat')
IPER_KUR_BEN=RISULTATI_FINALI;

n_gradi=5;
n_topologie=100;
n_tipi=4;
fs=13;

matrice_gruppo=cell(5);
matrice_gruppo{1}=[ones(1,3); zeros(4,3)];
matrice_gruppo{2}=[zeros(1,3); ones(1,3); zeros(3,3)];
matrice_gruppo{3}=[zeros(2,3); ones(1,3); zeros(2,3)];
matrice_gruppo{4}=[zeros(3,3); ones(1,3); zeros(1,3)];
matrice_gruppo{5}=[zeros(4,3); ones(1,3)];

%Colori
nero=[0 0 0];
grigio=[0.6 0.6 0.6];
rosso_pallido=[0.3010 0.7450 0.9330];
bianco=[1 1 1];

%ANOVA

vettori_bound_stimati_grafi=cell(1,n_gradi);
vettori_bound_stimati_ipergrafi=cell(1,n_gradi);
vettori_bound_stimati_malefici=cell(1,n_gradi);
vettori_bound_stimati_benefici=cell(1,n_gradi);

vettori_bound_effettivi_grafi=cell(1,n_gradi);
vettori_bound_effettivi_ipergrafi=cell(1,n_gradi);
vettori_bound_effettivi_malefici=cell(1,n_gradi);
vettori_bound_effettivi_benefici=cell(1,n_gradi);

for G=1:n_gradi

    vettore_grafi=zeros(1,n_topologie);
    vettore_ipergrafi=zeros(1,n_topologie);
    vettore_malefici=zeros(1,n_topologie);
    vettore_benefici=zeros(1,n_topologie);

    vettore_grafi_eff=zeros(1,n_topologie);
    vettore_ipergrafi_eff=zeros(1,n_topologie);
    vettore_malefici_eff=zeros(1,n_topologie);
    vettore_benefici_eff=zeros(1,n_topologie);

    gruppo_graf=GRA_KUR{G};
    gruppo_iper_mix=IPER_KUR{G};
    gruppo_iper_mal=IPER_KUR_MAL{G};
    gruppo_iper_ben=IPER_KUR_BEN{G};

    for T=1:n_topologie

        if gruppo_graf(T).condition_number<1000 %questo valore deve essere abbastanza alto perchè voglio effettivamente eliminare i doppi zeri. Essi hanno un cn altissimo.

            vettore_grafi(T)=gruppo_graf(T).bound_stimato;
            vettore_grafi_eff(T)=gruppo_graf(T).bound_effettivo;

        end

        if gruppo_iper_mix(T).condition_number<1000

            vettore_ipergrafi(T)=gruppo_iper_mix(T).bound_stimato;
            vettore_ipergrafi_eff(T)=gruppo_iper_mix(T).bound_effettivo;

            
        end

        if gruppo_iper_mal(T).condition_number<1000

            vettore_malefici(T)=gruppo_iper_mal(T).bound_stimato;
            vettore_malefici_eff(T)=gruppo_iper_mal(T).bound_effettivo;

            
        end

        if gruppo_iper_ben(T).condition_number<1000

            vettore_benefici(T)=gruppo_iper_ben(T).bound_stimato;
            vettore_benefici_eff(T)=gruppo_iper_ben(T).bound_effettivo;
            
        end

    end

    vettori_bound_stimati_grafi{G}=nonzeros(vettore_grafi)';
    vettori_bound_stimati_ipergrafi{G}=nonzeros(vettore_ipergrafi)';
    vettori_bound_stimati_malefici{G}=nonzeros(vettore_malefici)';
    vettori_bound_stimati_benefici{G}=nonzeros(vettore_benefici)';

    vettori_bound_effettivi_grafi{G}=nonzeros(vettore_grafi_eff)';
    vettori_bound_effettivi_ipergrafi{G}=nonzeros(vettore_ipergrafi_eff)';
    vettori_bound_effettivi_malefici{G}=nonzeros(vettore_malefici_eff)';
    vettori_bound_effettivi_benefici{G}=nonzeros(vettore_benefici_eff)';

end

%Anova per grado 8 10 12 14 16

[h_kur_8_grafi,p_8_kur_grafi]=lillietest(1./vettori_bound_stimati_grafi{1});
[h_kur_8_ipergrafi,p_8_kur_ipergrafi]=lillietest(1./vettori_bound_stimati_ipergrafi{1});
[h_kur_8_source,p_8_kur_source]=lillietest(1./vettori_bound_stimati_malefici{1});
[h_kur_8_sink,p_8_kur_sink]=lillietest(1./vettori_bound_stimati_benefici{1}); %non normali
vettore_bound_anova_8=[1./vettori_bound_stimati_grafi{1},1./vettori_bound_stimati_ipergrafi{1},1./vettori_bound_stimati_malefici{1},1./vettori_bound_stimati_benefici{1}];
vettore_gruppi_anova_8=[ones(1,size(vettori_bound_stimati_grafi{1},2)), 2*ones(1,size(vettori_bound_stimati_ipergrafi{1},2)), 3*ones(1,size(vettori_bound_stimati_malefici{1},2)),4*ones(1,size(vettori_bound_stimati_benefici{1},2))];
[aov_kur_8,~,stats_kur_8]=anova1(vettore_bound_anova_8,vettore_gruppi_anova_8,"off");
[p_kw_kur_8,~,stats_kw_kur_8]=kruskalwallis(vettore_bound_anova_8,vettore_gruppi_anova_8,"off"); %Scatola dei sink più grandicella delle altre

[p_we_kur_8, F_we_kur_8, df1_we_kur_8, df2_we_kur_8] = welch_anova(vettore_bound_anova_8, vettore_gruppi_anova_8);
risultati_posthoc_GH_we_kur_8 = games_howell(vettore_bound_anova_8, vettore_gruppi_anova_8);

[result_kur_8, means_8, ~, gnames]=multcompare(stats_kur_8,"CriticalValueType","tukey-kramer","Display","off");
[result_kw_kur_8, means_kw_8, ~, ~]=multcompare(stats_kw_kur_8,"CriticalValueType","tukey-kramer","Display","off");

[h_kur_10_grafi,p_10_kur_grafi]=lillietest(1./vettori_bound_stimati_grafi{2});
[h_kur_10_ipergrafi,p_10_kur_ipergrafi]=lillietest(1./vettori_bound_stimati_ipergrafi{2});
[h_kur_10_source,p_10_kur_source]=lillietest(1./vettori_bound_stimati_malefici{2});
[h_kur_10_sink,p_10_kur_sink]=lillietest(1./vettori_bound_stimati_benefici{2});  %non normali
vettore_bound_anova_10=[1./vettori_bound_stimati_grafi{2},1./vettori_bound_stimati_ipergrafi{2},1./vettori_bound_stimati_malefici{2},1./vettori_bound_stimati_benefici{2}];
vettore_gruppi_anova_10=[ones(1,size(vettori_bound_stimati_grafi{2},2)), 2*ones(1,size(vettori_bound_stimati_ipergrafi{2},2)), 3*ones(1,size(vettori_bound_stimati_malefici{2},2)),4*ones(1,size(vettori_bound_stimati_benefici{2},2))];
[aov_kur_10,~,stats_kur_10]=anova1(vettore_bound_anova_10,vettore_gruppi_anova_10,"off");
[p_kw_kur_10,~,stats_kw_kur_10]=kruskalwallis(vettore_bound_anova_10,vettore_gruppi_anova_10,"off");

[result_kur_10, means_10, ~, gnames]=multcompare(stats_kur_10,"CriticalValueType","tukey-kramer","Display","off");
[result_kw_kur_10, means_kw_10, ~, ~]=multcompare(stats_kw_kur_10,"CriticalValueType","tukey-kramer","Display","off");

[h_kur_12_grafi,p_12_kur_grafi]=lillietest(1./vettori_bound_stimati_grafi{3});
[h_kur_12_ipergrafi,p_12_kur_ipergrafi]=lillietest(1./vettori_bound_stimati_ipergrafi{3});
[h_kur_12_source,p_12_kur_source]=lillietest(1./vettori_bound_stimati_malefici{3});
[h_kur_12_sink,p_12_kur_sink]=lillietest(1./vettori_bound_stimati_benefici{3}); %non normali
vettore_bound_anova_12=[1./vettori_bound_stimati_grafi{3},1./vettori_bound_stimati_ipergrafi{3},1./vettori_bound_stimati_malefici{3},1./vettori_bound_stimati_benefici{3}];
vettore_gruppi_anova_12=[ones(1,size(vettori_bound_stimati_grafi{3},2)), 2*ones(1,size(vettori_bound_stimati_ipergrafi{3},2)), 3*ones(1,size(vettori_bound_stimati_malefici{3},2)),4*ones(1,size(vettori_bound_stimati_benefici{3},2))];
[aov_kur_12,~,stats_kur_12]=anova1(vettore_bound_anova_12,vettore_gruppi_anova_12,"off");
[p_kw_kur_12,~,stats_kw_kur_12]=kruskalwallis(vettore_bound_anova_12,vettore_gruppi_anova_12,"off");

[result_kur_12, means_12, ~, gnames]=multcompare(stats_kur_12,"CriticalValueType","tukey-kramer","Display","off");
[result_kw_kur_12, means_kw_12, ~, ~]=multcompare(stats_kw_kur_12,"CriticalValueType","tukey-kramer","Display","off");

[h_kur_14_grafi,p_14_kur_grafi]=lillietest(1./vettori_bound_stimati_grafi{4});
[h_kur_14_ipergrafi,p_14_kur_ipergrafi]=lillietest(1./vettori_bound_stimati_ipergrafi{4});
[h_kur_14_source,p_14_kur_source]=lillietest(1./vettori_bound_stimati_malefici{4});
[h_kur_14_sink,p_14_kur_sink]=lillietest(1./vettori_bound_stimati_benefici{4}); %non normali
vettore_bound_anova_14=[1./vettori_bound_stimati_grafi{4},1./vettori_bound_stimati_ipergrafi{4},1./vettori_bound_stimati_malefici{4},1./vettori_bound_stimati_benefici{4}];
vettore_gruppi_anova_14=[ones(1,size(vettori_bound_stimati_grafi{4},2)), 2*ones(1,size(vettori_bound_stimati_ipergrafi{4},2)), 3*ones(1,size(vettori_bound_stimati_malefici{4},2)),4*ones(1,size(vettori_bound_stimati_benefici{4},2))];
[aov_kur_14,~,stats_kur_14]=anova1(vettore_bound_anova_14,vettore_gruppi_anova_14,"off");
[p_kw_kur_14,~,stats_kw_kur_14]=kruskalwallis(vettore_bound_anova_14,vettore_gruppi_anova_14,"off");

[result_kur_14, means_14, ~, gnames]=multcompare(stats_kur_14,"CriticalValueType","tukey-kramer","Display","off");
[result_kw_kur_14, means_kw_14, ~, ~]=multcompare(stats_kw_kur_14,"CriticalValueType","tukey-kramer","Display","off");

[h_kur_16_grafi,p_16_kur_grafi]=lillietest(1./vettori_bound_stimati_grafi{5});
[h_kur_16_ipergrafi,p_16_kur_ipergrafi]=lillietest(1./vettori_bound_stimati_ipergrafi{5});
[h_kur_16_source,p_16_kur_source]=lillietest(1./vettori_bound_stimati_malefici{5});
[h_kur_16_sink,p_16_kur_sink]=lillietest(1./vettori_bound_stimati_benefici{5}); %non normali
vettore_bound_anova_16=[1./vettori_bound_stimati_grafi{5},1./vettori_bound_stimati_ipergrafi{5},1./vettori_bound_stimati_malefici{5},1./vettori_bound_stimati_benefici{5}];
vettore_gruppi_anova_16=[ones(1,size(vettori_bound_stimati_grafi{5},2)), 2*ones(1,size(vettori_bound_stimati_ipergrafi{5},2)), 3*ones(1,size(vettori_bound_stimati_malefici{5},2)),4*ones(1,size(vettori_bound_stimati_benefici{5},2))];
[aov_kur_16,~,stats_kur_16]=anova1(vettore_bound_anova_16,vettore_gruppi_anova_16,"off");
[p_kw_kur_16,~,stats_kw_kur_16]=kruskalwallis(vettore_bound_anova_16,vettore_gruppi_anova_16,"off");

[result_kur_16, means_16, ~, gnames]=multcompare(stats_kur_16,"CriticalValueType","tukey-kramer","Display","off");
[result_kw_kur_16, means_kw_16, ~, ~]=multcompare(stats_kw_kur_16,"CriticalValueType","tukey-kramer","Display","off");

%Figura Tukey Kramer test per grado 

medie=[mean(1./vettori_bound_stimati_grafi{k}), mean(1./vettori_bound_stimati_malefici{k}), mean(1./vettori_bound_stimati_ipergrafi{k}), mean(1./vettori_bound_stimati_benefici{k})];
medie=medie*10; %Moltiplico per radical N
errori_std=[std(1./vettori_bound_stimati_grafi{k})/sqrt(size(vettori_bound_stimati_grafi{k},2)), std(1./vettori_bound_stimati_malefici{k})/sqrt(size(vettori_bound_stimati_malefici{k},2)), std(1./vettori_bound_stimati_ipergrafi{k})/sqrt(size(vettori_bound_stimati_ipergrafi{k},2)), std(1./vettori_bound_stimati_benefici{k})/sqrt(size(vettori_bound_stimati_benefici{k},2))];
errori_std=errori_std*10; %Moltiplico per radical 10

%  First panel TK figures (to be uncomment)

% figure
% subplot(1,2,1)
% B=bar(medie,0.7,'FaceColor','flat');
% B.CData(1,:) = rosso_pallido;
% B.CData(2,:) = nero;
% B.CData(3,:) = grigio;
% B.CData(4,:) = bianco;
% hold on
% b=errorbar(medie, errori_std,'vertical','LineStyle','none','LineWidth',2)
% b.Color="#A2142F";
% ylabel('$S$')
% xticks([1 2 3 4])
% xticklabels({'Digraphs', 'Source', 'ER', 'Sink'})
% xtickangle(90)
% yticks([0:30:180])
% limy=[0 180];
% ylim(limy)
% title('Kuramoto model')
% set(gca,'FontSize',fs)

%Calcolo il bound stimato mediano per i grafi ed ipergrafi_mix

vettore_bound_mediani_grafi=zeros(1,n_gradi);
vettore_bound_mediani_ipergrafi_mix=zeros(1,n_gradi);

for G=1:n_gradi

    vettore_bound_stim_grafi=zeros(1,n_topologie);
    vettore_bound_stim_ipergrafi_mix=zeros(1,n_topologie);

    gruppo_graf=GRA_KUR{G};
    gruppo_iper_mix=IPER_KUR{G};

    for T=1:n_topologie

        vettore_bound_stim_grafi(T)=gruppo_graf(T).bound_stimato;
        vettore_bound_stim_ipergrafi_mix(T)=gruppo_iper_mix(T).bound_stimato;

    end

    vettore_bound_mediani_grafi(G)=median(vettore_bound_stim_grafi);
    vettore_bound_mediani_ipergrafi_mix(G)=median(vettore_bound_stim_ipergrafi_mix);

end

volte_peggio_misti=zeros(1,n_gradi);
volte_meglio_misti=zeros(1,n_gradi);
volte_peggio_doppio_zero_misti=zeros(1,n_gradi);

volte_peggio_ben=zeros(1,n_gradi);
volte_meglio_ben=zeros(1,n_gradi);
volte_peggio_doppio_zero_ben=zeros(1,n_gradi);

volte_peggio_mal=zeros(1,n_gradi);
volte_meglio_mal=zeros(1,n_gradi);
volte_peggio_doppio_zero_mal=zeros(1,n_gradi);

%Confronto ipergrafi

volte_mix_peggio_ben=zeros(1,n_gradi);
volte_mix_meglio_ben=zeros(1,n_gradi);
volte_mix_peggio_doppio_zero_ben=zeros(1,n_gradi);

volte_mix_peggio_mal=zeros(1,n_gradi);
volte_mix_meglio_mal=zeros(1,n_gradi);
volte_mix_peggio_doppio_zero_mal=zeros(1,n_gradi);

for G=1:n_gradi

    gruppo_misti=IPER_KUR{G};
    gruppo_ben=IPER_KUR_BEN{G};
    gruppo_mal=IPER_KUR_MAL{G};

    for T=1:n_topologie

        %Misti

        if gruppo_misti(T).bound_stimato>vettore_bound_mediani_grafi(G)

            volte_peggio_misti(G)=volte_peggio_misti(G)+1;

        else

            volte_meglio_misti(G)=volte_meglio_misti(G)+1;

        end

        if gruppo_misti(T).bound_stimato>vettore_bound_mediani_grafi(G) & gruppo_misti(T).condition_number>1e10

            volte_peggio_doppio_zero_misti(G)=volte_peggio_doppio_zero_misti(G)+1;

        end

        %Malefici

        if gruppo_mal(T).bound_stimato>vettore_bound_mediani_grafi(G)

            volte_peggio_mal(G)=volte_peggio_mal(G)+1;

        else

            volte_meglio_mal(G)=volte_meglio_mal(G)+1;

        end

        if gruppo_mal(T).bound_stimato>vettore_bound_mediani_grafi(G) & gruppo_mal(T).condition_number>1e10

            volte_peggio_doppio_zero_mal(G)=volte_peggio_doppio_zero_mal(G)+1;

        end

            %Ipergrafi

        if gruppo_mal(T).bound_stimato>vettore_bound_mediani_ipergrafi_mix(G)

            volte_mix_peggio_mal(G)=volte_mix_peggio_mal(G)+1;

        else

            volte_mix_meglio_mal(G)=volte_mix_meglio_mal(G)+1;

        end

        if gruppo_mal(T).bound_stimato>vettore_bound_mediani_ipergrafi_mix(G) & gruppo_mal(T).condition_number>1e10

            volte_mix_peggio_doppio_zero_mal(G)=volte_mix_peggio_doppio_zero_mal(G)+1;

        end

        %Benefici

        if gruppo_ben(T).bound_stimato>vettore_bound_mediani_grafi(G)

            volte_peggio_ben(G)=volte_peggio_ben(G)+1;

        else

            volte_meglio_ben(G)=volte_meglio_ben(G)+1;

        end

        if gruppo_ben(T).bound_stimato>vettore_bound_mediani_grafi(G) & gruppo_ben(T).condition_number>1e10

            volte_peggio_doppio_zero_ben(G)=volte_peggio_doppio_zero_ben(G)+1;

        end

            %Ipergrafi

        if gruppo_ben(T).bound_stimato>vettore_bound_mediani_ipergrafi_mix(G)

            volte_mix_peggio_ben(G)=volte_mix_peggio_ben(G)+1;

        else

            volte_mix_meglio_ben(G)=volte_mix_meglio_ben(G)+1;

        end

        if gruppo_ben(T).bound_stimato>vettore_bound_mediani_ipergrafi_mix(G) & gruppo_ben(T).condition_number>1e10

            volte_mix_peggio_doppio_zero_ben(G)=volte_mix_peggio_doppio_zero_ben(G)+1;

        end

    end

end

figure
subplot(2,2,1)
barre_kur_grafi=[-volte_peggio_ben; -volte_peggio_misti; -volte_peggio_mal]';
barre_kur_grafi=barre_kur_grafi/n_topologie;
bb = bar(barre_kur_grafi,'FaceColor','flat');
bb(1).FaceColor = bianco;
bb(2).FaceColor = grigio;
bb(3).FaceColor = nero;
hold on
barre_kur_grafi=[volte_meglio_ben; volte_meglio_misti; volte_meglio_mal]';
barre_kur_grafi=barre_kur_grafi/n_topologie;
bar(barre_kur_grafi)
b = bar(barre_kur_grafi,'FaceColor','flat');
b(1).FaceColor = bianco;
b(2).FaceColor = grigio;
b(3).FaceColor = nero;
xticks([1 2 3 4 5])
xticklabels([8 10 12 14 16])
yticks([-1 -0.5 0 0.5 1])
limy=[-1.2 1.2];
ylim(limy)
xlabel("$\overline k$")
%ylabel("$Y$")
title('Kuramoto models','Position',[3 1.4 0])
legend({'Sink hypergraphs','ER hypergraphs','Source hypergraphs'},'Interpreter','latex','Position',[0.1638, 0.8405, 0.1, 0.1],'FontSize',9)
set(gca,'FontSize',fs)

subplot(2,2,3)
barre_kur_ipergrafimix=[-volte_mix_peggio_ben; -volte_mix_peggio_mal]';
barre_kur_ipergrafimix=barre_kur_ipergrafimix/n_topologie;
b1a = bar(barre_kur_ipergrafimix,'FaceColor','flat');
b1a(1).FaceColor = bianco;
b1a(2).FaceColor = nero;
hold on
barre_kur_ipergrafimix=[volte_mix_meglio_ben; volte_mix_meglio_mal]';
barre_kur_ipergrafimix=barre_kur_ipergrafimix/n_topologie;
b1 = bar(barre_kur_ipergrafimix,'FaceColor','flat');
b1(1).FaceColor = bianco;
b1(2).FaceColor = nero;
hatchfill2(b1(1),'single','HatchAngle',45,'HatchColor','k');
hatchfill2(b1(2),'single','HatchAngle',45,'HatchColor','w');
xticks([1 2 3 4 5])
xticklabels([8 10 12 14 16])
yticks([-1 -0.5 0 0.5 1])
limy=[-1.2 1.2];
ylim(limy)
xlabel("$\overline k$")
legend({'Sink hypergraphs','Source hypergraphs'},'Interpreter','latex','Position',[0.1638, 0.3923, 0.1, 0.07],'FontSize',9)
set(gca,'FontSize',fs)

%%ROSSLER

load('gra_deg_cresc_ross_100top_eps1_v2.mat')
GRA_ROSS=RISULTATI_FINALI;
load('hyp_deg_cresc_ross_100top_eps1_v2.mat')
IPER_ROSS=RISULTATI_FINALI;
load('hyp_deg_cresc_source_ross_100top_eps1_v2.mat')
IPER_ROSS_MAL=RISULTATI_FINALI;
load('hyp_deg_cresc_sink_ross_100top_eps1_v2.mat')
IPER_ROSS_BEN=RISULTATI_FINALI;

%Anova

vettori_bound_stimati_grafi=cell(1,n_gradi);
vettori_bound_stimati_ipergrafi=cell(1,n_gradi);
vettori_bound_stimati_malefici=cell(1,n_gradi);
vettori_bound_stimati_benefici=cell(1,n_gradi);

for G=1:n_gradi

    vettore_grafi=zeros(n_topologie,1);
    vettore_ipergrafi=zeros(n_topologie,1);
    vettore_malefici=zeros(n_topologie,1);
    vettore_benefici=zeros(n_topologie,1);

    gruppo_graf=GRA_ROSS{G};
    gruppo_iper_mix=IPER_ROSS{G};
    gruppo_iper_mal=IPER_ROSS_MAL{G};
    gruppo_iper_ben=IPER_ROSS_BEN{G};

    for T=1:n_topologie
        
        if gruppo_graf(T).bound_stimato>0

            vettore_grafi(T)=gruppo_graf(T).bound_stimato;

        end

        if gruppo_iper_mix(T).bound_stimato>0

            vettore_ipergrafi(T)=gruppo_iper_mix(T).bound_stimato;
            
        end

        if gruppo_iper_mal(T).bound_stimato>0

            vettore_malefici(T)=gruppo_iper_mal(T).bound_stimato;
            
        end

        if gruppo_iper_ben(T).bound_stimato>0

            vettore_benefici(T)=gruppo_iper_ben(T).bound_stimato;
            
        end

    end

    vettori_bound_stimati_grafi{G}=nonzeros(vettore_grafi)';
    vettori_bound_stimati_ipergrafi{G}=nonzeros(vettore_ipergrafi)';
    vettori_bound_stimati_malefici{G}=nonzeros(vettore_malefici)';
    vettori_bound_stimati_benefici{G}=nonzeros(vettore_benefici)';

end

%Anova per grado 8 10 12 14 16

[h_ross_8_grafi,p_8_ross_grafi]=lillietest(1./vettori_bound_stimati_grafi{1}); %non normali
[h_ross_8_ipergrafi,p_8_ross_ipergrafi]=lillietest(1./vettori_bound_stimati_ipergrafi{1});
[h_ross_8_source,p_8_ross_source]=lillietest(1./vettori_bound_stimati_malefici{1}); %non normali
[h_ross_8_sink,p_8_ross_sink]=lillietest(1./vettori_bound_stimati_benefici{1});
vettore_bound_anova_8=[1./vettori_bound_stimati_grafi{1},1./vettori_bound_stimati_ipergrafi{1},1./vettori_bound_stimati_malefici{1},1./vettori_bound_stimati_benefici{1}];
vettore_gruppi_anova_8=[ones(1,size(vettori_bound_stimati_grafi{1},2)), 2*ones(1,size(vettori_bound_stimati_ipergrafi{1},2)), 3*ones(1,size(vettori_bound_stimati_malefici{1},2)),4*ones(1,size(vettori_bound_stimati_benefici{1},2))];
[aov_ross_8,~,stats_ross_8]=anova1(vettore_bound_anova_8,vettore_gruppi_anova_8,"off");
[p_kw_ross_8,~,stats_kw_ross_8]=kruskalwallis(vettore_bound_anova_8,vettore_gruppi_anova_8,"off");

[result_ross_8, means_8, ~, gnames]=multcompare(stats_ross_8,"CriticalValueType","tukey-kramer","Display","off");
[result_kw_ross_8, means_kw_8, ~, ~]=multcompare(stats_kw_ross_8,"CriticalValueType","tukey-kramer","Display","off");

[h_ross_10_grafi,p_10_ross_grafi]=lillietest(1./vettori_bound_stimati_grafi{2});
[h_ross_10_ipergrafi,p_10_ross_ipergrafi]=lillietest(1./vettori_bound_stimati_ipergrafi{2}); %non normali
[h_ross_10_source,p_10_ross_source]=lillietest(1./vettori_bound_stimati_malefici{2});
[h_ross_10_sink,p_10_ross_sink]=lillietest(1./vettori_bound_stimati_benefici{2});
vettore_bound_anova_10=[1./vettori_bound_stimati_grafi{2},1./vettori_bound_stimati_ipergrafi{2},1./vettori_bound_stimati_malefici{2},1./vettori_bound_stimati_benefici{2}];
vettore_gruppi_anova_10=[ones(1,size(vettori_bound_stimati_grafi{2},2)), 2*ones(1,size(vettori_bound_stimati_ipergrafi{2},2)), 3*ones(1,size(vettori_bound_stimati_malefici{2},2)),4*ones(1,size(vettori_bound_stimati_benefici{2},2))];
[aov_ross_10,~,stats_ross_10]=anova1(vettore_bound_anova_10,vettore_gruppi_anova_10,"off");
[p_kw_ross_10,~,stats_kw_ross_10]=kruskalwallis(vettore_bound_anova_10,vettore_gruppi_anova_10,"off");

[result_ross_10, means_10, ~, gnames]=multcompare(stats_ross_10,"CriticalValueType","tukey-kramer","Display","off");
[result_kw_ross_10, means_kw_10, ~, ~]=multcompare(stats_kw_ross_10,"CriticalValueType","tukey-kramer","Display","off");

[h_ross_12_grafi,p_12_ross_grafi]=lillietest(1./vettori_bound_stimati_grafi{3});
[h_ross_12_ipergrafi,p_12_ross_ipergrafi]=lillietest(1./vettori_bound_stimati_ipergrafi{3});
[h_ross_12_source,p_12_ross_source]=lillietest(1./vettori_bound_stimati_malefici{3});
[h_ross_12_sink,p_12_ross_sink]=lillietest(1./vettori_bound_stimati_benefici{3});  %non normali
vettore_bound_anova_12=[1./vettori_bound_stimati_grafi{3},1./vettori_bound_stimati_ipergrafi{3},1./vettori_bound_stimati_malefici{3},1./vettori_bound_stimati_benefici{3}];
vettore_gruppi_anova_12=[ones(1,size(vettori_bound_stimati_grafi{3},2)), 2*ones(1,size(vettori_bound_stimati_ipergrafi{3},2)), 3*ones(1,size(vettori_bound_stimati_malefici{3},2)),4*ones(1,size(vettori_bound_stimati_benefici{3},2))];
[aov_ross_12,~,stats_ross_12]=anova1(vettore_bound_anova_12,vettore_gruppi_anova_12,"off");
[p_kw_ross_12,~,stats_kw_ross_12]=kruskalwallis(vettore_bound_anova_12,vettore_gruppi_anova_12,"off");

[result_ross_12, means_12, ~, gnames]=multcompare(stats_ross_12,"CriticalValueType","tukey-kramer","Display","off");
[result_kw_ross_12, means_kw_12, ~, ~]=multcompare(stats_kw_ross_12,"CriticalValueType","tukey-kramer","Display","off");

[h_ross_14_grafi,p_14_ross_grafi]=lillietest(1./vettori_bound_stimati_grafi{4});
[h_ross_14_ipergrafi,p_14_ross_ipergrafi]=lillietest(1./vettori_bound_stimati_ipergrafi{4});
[h_ross_14_source,p_14_ross_source]=lillietest(1./vettori_bound_stimati_malefici{4});
[h_ross_14_sink,p_14_ross_sink]=lillietest(1./vettori_bound_stimati_benefici{4});
vettore_bound_anova_14=[1./vettori_bound_stimati_grafi{4},1./vettori_bound_stimati_ipergrafi{4},1./vettori_bound_stimati_malefici{4},1./vettori_bound_stimati_benefici{4}];
vettore_gruppi_anova_14=[ones(1,size(vettori_bound_stimati_grafi{4},2)), 2*ones(1,size(vettori_bound_stimati_ipergrafi{4},2)), 3*ones(1,size(vettori_bound_stimati_malefici{4},2)),4*ones(1,size(vettori_bound_stimati_benefici{4},2))];
[aov_ross_14,~,stats_ross_14]=anova1(vettore_bound_anova_14,vettore_gruppi_anova_14,"off");
[p_kw_ross_14,~,stats_kw_ross_14]=kruskalwallis(vettore_bound_anova_14,vettore_gruppi_anova_14,"off");

[result_ross_14, means_14, ~, gnames]=multcompare(stats_ross_14,"CriticalValueType","tukey-kramer","Display","off");
[result_kw_ross_14, means_kw_14, ~, ~]=multcompare(stats_kw_ross_14,"CriticalValueType","tukey-kramer","Display","off");

[h_ross_16_grafi,p_16_ross_grafi]=lillietest(1./vettori_bound_stimati_grafi{5});
[h_ross_16_ipergrafi,p_16_ross_ipergrafi]=lillietest(1./vettori_bound_stimati_ipergrafi{5});
[h_ross_16_source,p_16_ross_source]=lillietest(1./vettori_bound_stimati_malefici{5}); %non normali
[h_ross_16_sink,p_16_ross_sink]=lillietest(1./vettori_bound_stimati_benefici{5}); %non normali
vettore_bound_anova_16=[1./vettori_bound_stimati_grafi{5},1./vettori_bound_stimati_ipergrafi{5},1./vettori_bound_stimati_malefici{5},1./vettori_bound_stimati_benefici{5}];
vettore_gruppi_anova_16=[ones(1,size(vettori_bound_stimati_grafi{5},2)), 2*ones(1,size(vettori_bound_stimati_ipergrafi{5},2)), 3*ones(1,size(vettori_bound_stimati_malefici{5},2)),4*ones(1,size(vettori_bound_stimati_benefici{5},2))];
[aov_ross_16,~,stats_ross_16]=anova1(vettore_bound_anova_16,vettore_gruppi_anova_16,"off");
[p_kw_ross_16,~,stats_kw_ross_16]=kruskalwallis(vettore_bound_anova_16,vettore_gruppi_anova_16,"off");

[result_ross_16, means_16, ~, gnames]=multcompare(stats_ross_16,"CriticalValueType","tukey-kramer","Display","off");
[result_kw_ross_16, means_kw_16, ~, ~]=multcompare(stats_kw_ross_16,"CriticalValueType","tukey-kramer","Display","off");


medie=[mean(1./vettori_bound_stimati_grafi{kk}), mean(1./vettori_bound_stimati_malefici{kk}), mean(1./vettori_bound_stimati_ipergrafi{kk}), mean(1./vettori_bound_stimati_benefici{kk})];
medie=medie*10; %Moltiplico per radical N
errori_std=[std(1./vettori_bound_stimati_grafi{kk})/sqrt(size(vettori_bound_stimati_grafi{kk},2)), std(1./vettori_bound_stimati_malefici{kk})/sqrt(size(vettori_bound_stimati_malefici{kk},2)), std(1./vettori_bound_stimati_ipergrafi{kk})/sqrt(size(vettori_bound_stimati_ipergrafi{kk},2)), std(1./vettori_bound_stimati_benefici{kk})/sqrt(size(vettori_bound_stimati_benefici{kk},2))];
errori_std=errori_std*10; %Moltiplico per radical N

%  Second panel TK figures (to be uncommented)

% subplot(1,2,2)
% B=bar(medie,0.7,'FaceColor','flat');
% B.CData(1,:) = rosso_pallido;
% B.CData(2,:) = nero;
% B.CData(3,:) = grigio;
% B.CData(4,:) = bianco;
% hold on
% b=errorbar(medie, errori_std,'vertical','LineStyle','none','LineWidth',2)
% b.Color="#A2142F";
% ylabel('$S$')
% xticks([1 2 3 4])
% xticklabels({'Digraphs', 'Source', 'ER', 'Sink'})
% yticks([0:250:1250])
% xtickangle(90)
% limy=[0 1250];
% ylim(limy)
% title('R\"ossler systems')
% set(gca,'FontSize',fs)

%Calcolo il bound stimato mediano per i grafi ed ipergrafi_mix

vettore_bound_mediani_grafi=zeros(1,n_gradi);
vettore_bound_mediani_ipergrafi_mix=zeros(1,n_gradi);

for G=1:n_gradi

    vettore_bound_stim_grafi=zeros(1,n_topologie);
    vettore_bound_stim_ipergrafi_mix=zeros(1,n_topologie);

    gruppo_graf=GRA_ROSS{G};
    gruppo_iper_mix=IPER_ROSS{G};

    for T=1:n_topologie

        vettore_bound_stim_grafi(T)=gruppo_graf(T).bound_stimato;
        vettore_bound_stim_ipergrafi_mix(T)=gruppo_iper_mix(T).bound_stimato;

    end

    vettore_bound_mediani_grafi(G)=median(vettore_bound_stim_grafi);
    vettore_bound_mediani_ipergrafi_mix(G)=median(vettore_bound_stim_ipergrafi_mix);

end

volte_peggio_misti=zeros(1,n_gradi);
volte_meglio_misti=zeros(1,n_gradi);
volte_peggio_doppio_zero_misti=zeros(1,n_gradi);
volte_ipotesi_non_sodd_misti=zeros(1,n_gradi);

volte_peggio_ben=zeros(1,n_gradi);
volte_meglio_ben=zeros(1,n_gradi);
volte_peggio_doppio_zero_ben=zeros(1,n_gradi);
volte_ipotesi_non_sodd_ben=zeros(1,n_gradi);

volte_peggio_mal=zeros(1,n_gradi);
volte_meglio_mal=zeros(1,n_gradi);
volte_peggio_doppio_zero_mal=zeros(1,n_gradi);
volte_ipotesi_non_sodd_mal=zeros(1,n_gradi);

%Confronto ipergrafi

volte_mix_peggio_ben=zeros(1,n_gradi);
volte_mix_meglio_ben=zeros(1,n_gradi);
volte_mix_peggio_doppio_zero_ben=zeros(1,n_gradi);
volte_mix_ipotesi_non_sodd_ben=zeros(1,n_gradi);

volte_mix_peggio_mal=zeros(1,n_gradi);
volte_mix_meglio_mal=zeros(1,n_gradi);
volte_mix_peggio_doppio_zero_mal=zeros(1,n_gradi);
volte_mix_ipotesi_non_sodd_mal=zeros(1,n_gradi);

for G=1:n_gradi

    gruppo_misti=IPER_ROSS{G};
    gruppo_ben=IPER_ROSS_BEN{G};
    gruppo_mal=IPER_ROSS_MAL{G};

    for T=1:n_topologie

        %Misti

        if gruppo_misti(T).bound_stimato>vettore_bound_mediani_grafi(G) 

            volte_peggio_misti(G)=volte_peggio_misti(G)+1;

        else 
            
            if  gruppo_misti(T).bound_stimato>0

            volte_meglio_misti(G)=volte_meglio_misti(G)+1;

            end

        end

        if gruppo_misti(T).bound_stimato<0

            volte_ipotesi_non_sodd_misti(G)=volte_ipotesi_non_sodd_misti(G)+1;

        end

        if gruppo_misti(T).condition_number>10e10

            volte_peggio_doppio_zero_misti(G)=volte_peggio_doppio_zero_misti(G)+1;

        end

        %Malefici

        if gruppo_mal(T).bound_stimato>vettore_bound_mediani_grafi(G)  

            volte_peggio_mal(G)=volte_peggio_mal(G)+1;

        else

            if gruppo_mal(T).bound_stimato>0

                volte_meglio_mal(G)=volte_meglio_mal(G)+1;

            end

        end

        if gruppo_mal(T).bound_stimato<0

            volte_ipotesi_non_sodd_mal(G)=volte_ipotesi_non_sodd_mal(G)+1;

        end

        if gruppo_mal(T).condition_number>10e10

            volte_peggio_doppio_zero_mal(G)=volte_peggio_doppio_zero_mal(G)+1;

        end

            %Ipergrafi

        if gruppo_mal(T).bound_stimato>vettore_bound_mediani_ipergrafi_mix(G)

            volte_mix_peggio_mal(G)=volte_mix_peggio_mal(G)+1;

        else

            if gruppo_mal(T).bound_stimato>0

                volte_mix_meglio_mal(G)=volte_mix_meglio_mal(G)+1;

            end

        end

        if gruppo_mal(T).bound_stimato<0

            volte_mix_ipotesi_non_sodd_mal(G)=volte_mix_ipotesi_non_sodd_mal(G)+1;

        end

        if gruppo_mal(T).condition_number>10e10

            volte_mix_peggio_doppio_zero_mal(G)=volte_mix_peggio_doppio_zero_mal(G)+1;

        end

        %Benefici

        if gruppo_ben(T).bound_stimato>vettore_bound_mediani_grafi(G)

            volte_peggio_ben(G)=volte_peggio_ben(G)+1;

        else

            if gruppo_ben(T).bound_stimato>0

                volte_meglio_ben(G)=volte_meglio_ben(G)+1;

            end

        end

        if gruppo_ben(T).bound_stimato<0

            volte_ipotesi_non_sodd_ben(G)=volte_ipotesi_non_sodd_ben(G)+1;

        end

        if gruppo_ben(T).condition_number>10e10

            volte_peggio_doppio_zero_ben(G)=volte_peggio_doppio_zero_ben(G)+1;

        end

            %Ipergrafi

        if gruppo_ben(T).bound_stimato>vettore_bound_mediani_ipergrafi_mix(G)

            volte_mix_peggio_ben(G)=volte_mix_peggio_ben(G)+1;

        else

            if gruppo_ben(T).bound_stimato>0

                volte_mix_meglio_ben(G)=volte_mix_meglio_ben(G)+1;

            end

        end

        if gruppo_ben(T).bound_stimato<0

            volte_mix_ipotesi_non_sodd_ben(G)=volte_mix_ipotesi_non_sodd_ben(G)+1;

        end

        if gruppo_ben(T).condition_number>10e10

            volte_mix_peggio_doppio_zero_ben(G)=volte_mix_peggio_doppio_zero_ben(G)+1;

        end

    end

end

a=volte_peggio_misti+volte_meglio_misti+volte_ipotesi_non_sodd_misti;
b=volte_peggio_mal+volte_meglio_mal+volte_ipotesi_non_sodd_mal;
c=volte_mix_peggio_mal+volte_mix_meglio_mal+volte_mix_ipotesi_non_sodd_mal;
d=volte_peggio_ben+volte_meglio_ben+volte_ipotesi_non_sodd_ben;
e=volte_mix_peggio_ben+volte_mix_meglio_ben+volte_mix_ipotesi_non_sodd_ben;


subplot(2,2,2)

%Primo gruppo
barre_kur_grafi=[-volte_peggio_ben-volte_ipotesi_non_sodd_ben; -volte_peggio_misti-volte_ipotesi_non_sodd_misti; -volte_peggio_mal-volte_ipotesi_non_sodd_mal]';
barre_kur_grafi=barre_kur_grafi/n_topologie;
bb = bar(barre_kur_grafi,'FaceColor','flat');
bb(1).FaceColor = bianco;
bb(2).FaceColor = grigio;
bb(3).FaceColor = nero;
hold on
barre_kur_grafi=[volte_meglio_ben; volte_meglio_misti; volte_meglio_mal]';
barre_kur_grafi=barre_kur_grafi/n_topologie;
bd = bar(barre_kur_grafi,'FaceColor','flat');
bd(1).FaceColor = bianco;
bd(2).FaceColor = grigio;
bd(3).FaceColor = nero;

xticklabels([8 10 12 14 16])
yticks([-1 -0.5 0 0.5 1])
limy=[-1.2 1.2];
ylim(limy)
xlabel("$\overline k$")
title('Coupled R\"ossler systems','Position',[3 1.4 0])
legend({'Sink hypergraphs','ER hypergraphs','Source hypergraphs'},'Interpreter','latex','Position',[0.6037, 0.8405, 0.1, 0.1],'FontSize',9)
set(gca,'FontSize',fs)

subplot(2,2,4)

%Primo gruppo
barre_kur_ipergrafimix=[-volte_mix_peggio_ben-volte_mix_ipotesi_non_sodd_ben; -volte_mix_peggio_mal-volte_mix_ipotesi_non_sodd_mal]';
barre_kur_ipergrafimix=barre_kur_ipergrafimix/n_topologie;
b1a = bar(barre_kur_ipergrafimix,'FaceColor','flat');
b1a(1).FaceColor = bianco;
b1a(2).FaceColor = nero;
hold on
barre_kur_ipergrafimix=[volte_mix_meglio_ben; volte_mix_meglio_mal]';
barre_kur_ipergrafimix=barre_kur_ipergrafimix/n_topologie;
b1d = bar(barre_kur_ipergrafimix,'FaceColor','flat');
b1d(1).FaceColor = bianco;
b1d(2).FaceColor = nero;
hatchfill2(b1d(1),'single','HatchAngle',45,'HatchColor','k');
hatchfill2(b1d(2),'single','HatchAngle',45,'HatchColor','w');

xticklabels([8 10 12 14 16])
yticks([-1 -0.5 0 0.5 1])
limy=[-1.2 1.2];
ylim(limy)
xlabel("$\overline k$")
legend({'Sink hypergraphs','Source hypergraphs'},'Interpreter','latex','Position',[0.6037, 0.4015, 0.1, 0.05],'FontSize',9)
set(gca,'FontSize',fs)

set(gcf, 'Position',  [250, 125, 825, 650]);

% set(gcf, 'Position',  [250, 125, 825, 350]); % size of TK figures (to be uncommented)