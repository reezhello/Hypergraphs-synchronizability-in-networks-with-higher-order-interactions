clear all 
close all 
clc

set(groot,'defaultAxesTickLabelInterpreter','latex')
set(groot,'defaultTextInterpreter','latex')

k=5;
kk=k;

load('gra_deg_8_10_12_14_16_kur_gauss.mat')
GRA_KUR=RISULTATI_FINALI;
load('hyp_deg_8_10_12_14_16_kur_gauss.mat')
IPER_KUR=RISULTATI_FINALI;
load('hyp_deg_8_source_kur_gauss.mat')
IPER_KUR_SOURCE=RISULTATI_FINALI;
load('hyp_deg_10_12_14_16_source_kur_gauss.mat')
RISULTATI_FINALI(1)=[];
IPER_KUR_SOURCE=[IPER_KUR_SOURCE RISULTATI_FINALI];
load('hyp_deg_8_sink_kur_gauss.mat')
IPER_KUR_SINK=RISULTATI_FINALI;
load('hyp_deg_10_sink_kur_gauss.mat')
RISULTATI_FINALI(1)=[];
IPER_KUR_SINK=[IPER_KUR_SINK RISULTATI_FINALI];
load('hyp_deg_12_14_16_sink_kur_gauss.mat')
RISULTATI_FINALI(1)=[];
RISULTATI_FINALI(1)=[];
IPER_KUR_SINK=[IPER_KUR_SINK RISULTATI_FINALI];

n_gradi=5;
n_topologie=100;
n_tipi=4;
fs=13;

%Colori
nero=[0 0 0];
grigio=[0.6 0.6 0.6];
azzurro=[0.3010 0.7450 0.9330];
bianco=[1 1 1];

%ANOVA

vettori_bound_stimati_grafi=cell(1,n_gradi);
vettori_bound_stimati_ipergrafi=cell(1,n_gradi);
vettori_bound_stimati_malefici=cell(1,n_gradi);
vettori_bound_stimati_benefici=cell(1,n_gradi);

vettori_bound_effettivi_grafi=cell(1,n_gradi);
vettori_bound_effettivi_ipergrafi=cell(1,n_gradi);
vettori_bound_effettivi_malefici=cell(1,n_gradi);
vettori_bound_effettivi_benefici=cell(1,n_gradi);

for G=1:n_gradi

    vettore_grafi=zeros(1,n_topologie);
    vettore_ipergrafi=zeros(1,n_topologie);
    vettore_malefici=zeros(1,n_topologie);
    vettore_benefici=zeros(1,n_topologie);

    vettore_grafi_eff=zeros(1,n_topologie);
    vettore_ipergrafi_eff=zeros(1,n_topologie);
    vettore_malefici_eff=zeros(1,n_topologie);
    vettore_benefici_eff=zeros(1,n_topologie);

    gruppo_graf=GRA_KUR{G};
    gruppo_iper_mix=IPER_KUR{G};
    gruppo_iper_mal=IPER_KUR_SOURCE{G};
    gruppo_iper_ben=IPER_KUR_SINK{G};

    for T=1:n_topologie

        if gruppo_graf(T).condition_number<1000 %questo valore deve essere abbastanza alto perchè voglio effettivamente eliminare i doppi zeri. Essi hanno un cn altissimo.

            vettore_grafi(T)=gruppo_graf(T).bound_stimato;
            vettore_grafi_eff(T)=gruppo_graf(T).bound_effettivo;

        end

        if gruppo_iper_mix(T).condition_number<1000

            vettore_ipergrafi(T)=gruppo_iper_mix(T).bound_stimato;
            vettore_ipergrafi_eff(T)=gruppo_iper_mix(T).bound_effettivo;

        end

        if gruppo_iper_mal(T).condition_number<1000

            vettore_malefici(T)=gruppo_iper_mal(T).bound_stimato;
            vettore_malefici_eff(T)=gruppo_iper_mal(T).bound_effettivo;

            
        end

        if gruppo_iper_ben(T).condition_number<1000

            vettore_benefici(T)=gruppo_iper_ben(T).bound_stimato;
            vettore_benefici_eff(T)=gruppo_iper_ben(T).bound_effettivo;
            
        end

    end

    vettori_bound_stimati_grafi{G}=nonzeros(vettore_grafi)';
    vettori_bound_stimati_ipergrafi{G}=nonzeros(vettore_ipergrafi)';
    vettori_bound_stimati_malefici{G}=nonzeros(vettore_malefici)';
    vettori_bound_stimati_benefici{G}=nonzeros(vettore_benefici)';

    vettori_bound_effettivi_grafi{G}=nonzeros(vettore_grafi_eff)';
    vettori_bound_effettivi_ipergrafi{G}=nonzeros(vettore_ipergrafi_eff)';
    vettori_bound_effettivi_malefici{G}=nonzeros(vettore_malefici_eff)';
    vettori_bound_effettivi_benefici{G}=nonzeros(vettore_benefici_eff)';

end

%Anova per grado 8 10 12 14 16

corr(vettori_bound_stimati_benefici{1}',vettori_bound_effettivi_benefici{1}',"Type","Pearson")
corr(vettori_bound_stimati_benefici{1}',vettori_bound_effettivi_benefici{1}',"Type","Kendall")

[h_kur_8_grafi,p_8_kur_grafi]=lillietest(1./vettori_bound_stimati_grafi{1}); %non normali
[h_kur_8_ipergrafi,p_8_kur_ipergrafi]=lillietest(1./vettori_bound_stimati_ipergrafi{1});
[h_kur_8_source,p_8_kur_source]=lillietest(1./vettori_bound_stimati_malefici{1});
[h_kur_8_sink,p_8_kur_sink]=lillietest(1./vettori_bound_stimati_benefici{1}); %non normali
vettore_bound_anova_8=[1./vettori_bound_stimati_grafi{1},1./vettori_bound_stimati_ipergrafi{1},1./vettori_bound_stimati_malefici{1},1./vettori_bound_stimati_benefici{1}];
vettore_gruppi_anova_8=[ones(1,size(vettori_bound_stimati_grafi{1},2)), 2*ones(1,size(vettori_bound_stimati_ipergrafi{1},2)), 3*ones(1,size(vettori_bound_stimati_malefici{1},2)),4*ones(1,size(vettori_bound_stimati_benefici{1},2))];
[aov_kur_8,~,stats_kur_8]=anova1(vettore_bound_anova_8,vettore_gruppi_anova_8,"off");
[p_kw_kur_8,~,stats_kw_kur_8]=kruskalwallis(vettore_bound_anova_8,vettore_gruppi_anova_8,"off"); %Scatola del gruppo 4 abbastanza diversa dalle altre.

[p_we_kur_8, F_we_kur_8, df1_we_kur_8, df2_we_kur_8] = welch_anova(vettore_bound_anova_8, vettore_gruppi_anova_8);
risultati_posthoc_GH_we_kur_8 = games_howell(vettore_bound_anova_8, vettore_gruppi_anova_8);

[result_kur_8, means_8, ~, ~]=multcompare(stats_kur_8,"CriticalValueType","tukey-kramer","Display","off");
[result_kw_kur_8, means_kw_8, ~, ~]=multcompare(stats_kw_kur_8,"CriticalValueType","tukey-kramer","Display","off");

[h_kur_10_grafi,p_10_kur_grafi]=lillietest(1./vettori_bound_stimati_grafi{2}); %non normali
[h_kur_10_ipergrafi,p_10_kur_ipergrafi]=lillietest(1./vettori_bound_stimati_ipergrafi{2});
[h_kur_10_source,p_10_kur_source]=lillietest(1./vettori_bound_stimati_malefici{2});
[h_kur_10_sink,p_10_kur_sink]=lillietest(1./vettori_bound_stimati_benefici{2}); %non normali
vettore_bound_anova_10=[1./vettori_bound_stimati_grafi{2},1./vettori_bound_stimati_ipergrafi{2},1./vettori_bound_stimati_malefici{2},1./vettori_bound_stimati_benefici{2}];
vettore_gruppi_anova_10=[ones(1,size(vettori_bound_stimati_grafi{2},2)), 2*ones(1,size(vettori_bound_stimati_ipergrafi{2},2)), 3*ones(1,size(vettori_bound_stimati_malefici{2},2)),4*ones(1,size(vettori_bound_stimati_benefici{2},2))];
[aov_kur_10,~,stats_kur_10]=anova1(vettore_bound_anova_10,vettore_gruppi_anova_10,"off");
[p_kw_kur_10,~,stats_kw_kur_10]=kruskalwallis(vettore_bound_anova_10,vettore_gruppi_anova_10,"off");

[result_kur_10, means_10, ~, gnames]=multcompare(stats_kur_10,"CriticalValueType","tukey-kramer","Display","off");
[result_kw_kur_10, means_kw_10, ~, ~]=multcompare(stats_kw_kur_10,"CriticalValueType","tukey-kramer","Display","off");

[h_kur_12_grafi,p_12_kur_grafi]=lillietest(1./vettori_bound_stimati_grafi{3});
[h_kur_12_ipergrafi,p_12_kur_ipergrafi]=lillietest(1./vettori_bound_stimati_ipergrafi{3});
[h_kur_12_source,p_12_kur_source]=lillietest(1./vettori_bound_stimati_malefici{3}); %non normali
[h_kur_12_sink,p_12_kur_sink]=lillietest(1./vettori_bound_stimati_benefici{3}); %non normali
vettore_bound_anova_12=[1./vettori_bound_stimati_grafi{3},1./vettori_bound_stimati_ipergrafi{3},1./vettori_bound_stimati_malefici{3},1./vettori_bound_stimati_benefici{3}];
vettore_gruppi_anova_12=[ones(1,size(vettori_bound_stimati_grafi{3},2)), 2*ones(1,size(vettori_bound_stimati_ipergrafi{3},2)), 3*ones(1,size(vettori_bound_stimati_malefici{3},2)),4*ones(1,size(vettori_bound_stimati_benefici{3},2))];
[aov_kur_12,~,stats_kur_12]=anova1(vettore_bound_anova_12,vettore_gruppi_anova_12,"off");
[p_kw_kur_12,~,stats_kw_kur_12]=kruskalwallis(vettore_bound_anova_12,vettore_gruppi_anova_12,"off");

[result_kur_12, means_12, ~, gnames]=multcompare(stats_kur_12,"CriticalValueType","tukey-kramer","Display","off");
[result_kw_kur_12, means_kw_12, ~, ~]=multcompare(stats_kw_kur_12,"CriticalValueType","tukey-kramer","Display","off");

[h_kur_14_grafi,p_14_kur_grafi]=lillietest(1./vettori_bound_stimati_grafi{4});
[h_kur_14_ipergrafi,p_14_kur_ipergrafi]=lillietest(1./vettori_bound_stimati_ipergrafi{4});
[h_kur_14_source,p_14_kur_source]=lillietest(1./vettori_bound_stimati_malefici{4});
[h_kur_14_sink,p_14_kur_sink]=lillietest(1./vettori_bound_stimati_benefici{4}); %non normali
vettore_bound_anova_14=[1./vettori_bound_stimati_grafi{4},1./vettori_bound_stimati_ipergrafi{4},1./vettori_bound_stimati_malefici{4},1./vettori_bound_stimati_benefici{4}];
vettore_gruppi_anova_14=[ones(1,size(vettori_bound_stimati_grafi{4},2)), 2*ones(1,size(vettori_bound_stimati_ipergrafi{4},2)), 3*ones(1,size(vettori_bound_stimati_malefici{4},2)),4*ones(1,size(vettori_bound_stimati_benefici{4},2))];
[aov_kur_14,~,stats_kur_14]=anova1(vettore_bound_anova_14,vettore_gruppi_anova_14,"off");
[p_kw_kur_14,~,stats_kw_kur_14]=kruskalwallis(vettore_bound_anova_14,vettore_gruppi_anova_14,"off");

[result_kur_14, means_14, ~, gnames]=multcompare(stats_kur_14,"CriticalValueType","tukey-kramer","Display","off");
[result_kw_kur_14, means_kw_14, ~, ~]=multcompare(stats_kw_kur_14,"CriticalValueType","tukey-kramer","Display","off");

[h_kur_16_grafi,p_16_kur_grafi]=lillietest(1./vettori_bound_stimati_grafi{5}); %non normali
[h_kur_16_ipergrafi,p_16_kur_ipergrafi]=lillietest(1./vettori_bound_stimati_ipergrafi{5});
[h_kur_16_source,p_16_kur_source]=lillietest(1./vettori_bound_stimati_malefici{5});
[h_kur_16_sink,p_16_kur_sink]=lillietest(1./vettori_bound_stimati_benefici{5}); 
vettore_bound_anova_16=[1./vettori_bound_stimati_grafi{5},1./vettori_bound_stimati_ipergrafi{5},1./vettori_bound_stimati_malefici{5},1./vettori_bound_stimati_benefici{5}];
vettore_gruppi_anova_16=[ones(1,size(vettori_bound_stimati_grafi{5},2)), 2*ones(1,size(vettori_bound_stimati_ipergrafi{5},2)), 3*ones(1,size(vettori_bound_stimati_malefici{5},2)),4*ones(1,size(vettori_bound_stimati_benefici{5},2))];
[aov_kur_16,~,stats_kur_16]=anova1(vettore_bound_anova_16,vettore_gruppi_anova_16,"off");
[p_kw_kur_16,~,stats_kw_kur_16]=kruskalwallis(vettore_bound_anova_16,vettore_gruppi_anova_16,"off");

[result_kur_16, means_16, ~, gnames]=multcompare(stats_kur_16,"CriticalValueType","tukey-kramer","Display","off");
[result_kw_kur_16, means_kw_16, ~, ~]=multcompare(stats_kw_kur_16,"CriticalValueType","tukey-kramer","Display","off");

%Figura Tukey Kramer test per grado 

medie=[mean(1./vettori_bound_stimati_grafi{k}), mean(1./vettori_bound_stimati_malefici{k}), mean(1./vettori_bound_stimati_ipergrafi{k}), mean(1./vettori_bound_stimati_benefici{k})];
medie=medie*10; %Moltiplico per radical N
errori_std=[std(1./vettori_bound_stimati_grafi{k})/sqrt(size(vettori_bound_stimati_grafi{k},2)), std(1./vettori_bound_stimati_malefici{k})/sqrt(size(vettori_bound_stimati_malefici{k},2)), std(1./vettori_bound_stimati_ipergrafi{k})/sqrt(size(vettori_bound_stimati_ipergrafi{k},2)), std(1./vettori_bound_stimati_benefici{k})/sqrt(size(vettori_bound_stimati_benefici{k},2))];
errori_std=errori_std*10; %Moltiplico per radical 10


figure
B=bar(medie,0.7,'FaceColor','flat');
B.CData(1,:) = azzurro;
B.CData(2,:) = nero;
B.CData(3,:) = grigio;
B.CData(4,:) = bianco;
hold on
b=errorbar(medie, errori_std,'vertical','LineStyle','none','LineWidth',2)
b.Color="#A2142F";
ylabel('$S$')
xticks([1 2 3 4])
xticklabels({'Digraphs', 'Source', 'ER', 'Sink'})
xtickangle(90)
yticks([0:30:240])
limy=[0 210];
ylim(limy)
title('Kuramoto model')
set(gca,'FontSize',fs)

set(gcf, 'Position',  [250, 125, 425, 350]);

