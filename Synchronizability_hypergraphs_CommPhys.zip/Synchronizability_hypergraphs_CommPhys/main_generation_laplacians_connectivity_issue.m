clear all 
close all 
clc

n_gruppi=5; %Numero di elementi nel vettore n_oggetti_imposti
RISULTATI_FINALI=cell(1,n_gruppi);

n_topologie=100;

%Dati dimensionali della rete desiderata

N=100;
sigma2=50;
sigma3=sigma2;
prob=[0.04 0.06 0.08 0.1 0.12];
n_oggetti_imposti=[800 1000 1200 1400 1600];
card=3;

for D=1:n_gruppi

%Struct che conterrà i risultati

risultati(n_topologie)=struct('simmetria_rete_a_ciclo_aperto',[],'numero_nodi',[],'grado_medio_in',[],'grado_medio_out',[],'sigma2',[],'sigma3',[],'condition_number',[],'autovalori_piu_piccoli',[]);
simulazioni_buone=1;

while simulazioni_buone<=n_topologie

    D
    simulazioni_buone

    %Genero la topologia con date caratteristiche

    %Uso questi per modulare il grado medio

%         [mat_e_testa_di, mat_e_coda_di]=generatore_ipergrafi_generali_esatti(N,card,grado_medio_imposto(D));
%         [mat_e_testa_di, mat_e_coda_di]=generatore_ipergrafi_generali_esatti_sink(N,card,grado_medio_imposto(D));
%         [mat_e_testa_di, mat_e_coda_di]=generatore_ipergrafi_generali_esatti_source(N,card,grado_medio_imposto(D));

    %Uso questi per modulare il numero di oggetti 

%         [mat_e_testa_di, mat_e_coda_di]=generatore_ipergrafi_generali_oggetti_imposti(N,card,n_oggetti_imposti(D));
%         [mat_e_testa_di, mat_e_coda_di]=generatore_ipergrafi_generali_oggetti_imposti_sink(N,card,n_oggetti_imposti(D));
         [mat_e_testa_di, mat_e_coda_di]=generatore_ipergrafi_generali_oggetti_imposti_source(N,card,n_oggetti_imposti(D));

    %Verifico il grado medio della rete generata
    d_out_medio=calcolo_grado_medio(mat_e_coda_di)  
    d_in_medio=calcolo_grado_medio(mat_e_testa_di)
    
    %Preparo il necessario per la simulazione
    [L,~]=adiacenza_e_laplaciano(mat_e_testa_di,mat_e_coda_di,N,size(mat_e_testa_di,1),sigma2/N,sigma3/N);

    vettore_d=zeros(N,1);

    for j=1:N

        vettore_d(j)=mean(L(:,j));

    end

    L_mod=L;

    for j=1:N

        L_mod(:,j)=L_mod(:,j)-vettore_d(j)*ones(N,1);

    end

    B=null(ones(1,N));

    F_inv=[ones(1,N);B'];

    F=inv(F_inv);

    L_disaccopp=F_inv*L_mod*F;
    
    L_rid=L_disaccopp(2:N,2:N);
    
    Sigma=lyap(L_rid',-eye(N-1));    

    L_u_bar=0.5*inv(Sigma);
    
    condizionamento=cond(L_u_bar);

    autoval=sort(eig(L_u_bar));

    due_autoval_piccoli=autoval(1:2);

    %Salvataggio dei risultati nella struct
    risultati(simulazioni_buone).grado_medio_out=d_out_medio;
    risultati(simulazioni_buone).grado_medio_in=d_in_medio;
    risultati(simulazioni_buone).simmetria_rete_a_ciclo_aperto=0;
    risultati(simulazioni_buone).numero_nodi=N;
    risultati(simulazioni_buone).sigma2=sigma2;
    risultati(simulazioni_buone).sigma3=sigma3;
    risultati(simulazioni_buone).condition_number=condizionamento;
    risultati(simulazioni_buone).autovalori_piu_piccoli=due_autoval_piccoli;

    simulazioni_buone=simulazioni_buone+1;

end

RISULTATI_FINALI{D}=risultati;

end

%Eventuale comando save 

% save("ipergrafi_grado_cresc_malefici_ANALISI_DOPPI_ZERI","RISULTATI_FINALI")