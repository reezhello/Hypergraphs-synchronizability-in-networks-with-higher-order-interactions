function [vettore_gradi, vettore_probabilita_estrazione_gradi] = degree_distribution(vettore_gradi_rete)    
    
    grado_massimo_rete=max(vettore_gradi_rete);

    vettore_probabilita_estrazione_gradi=zeros(1,grado_massimo_rete);
    vettore_gradi=1:grado_massimo_rete;

    for i=1:grado_massimo_rete

        cont=0;

        for j=1:size(vettore_gradi_rete,2)

            if vettore_gradi_rete(j)==i

                cont=cont+1;

            end

        end

        vettore_probabilita_estrazione_gradi(i)=cont/size(vettore_gradi_rete,2);

    end

end