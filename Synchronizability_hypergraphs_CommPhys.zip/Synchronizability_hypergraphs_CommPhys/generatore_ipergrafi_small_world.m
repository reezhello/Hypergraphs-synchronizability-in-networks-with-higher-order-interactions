function [mat_e_testa_di, mat_e_coda_di] = generatore_ipergrafi_small_world(N, p, num_vicini, f)
    % num_vicini: definisce quanti iperarchi partono da ogni nodo i.
    
    % Calcolo del numero totale di iperarchi
    num_iperarchi = N * num_vicini;
    
    % Inizializzazione delle matrici (righe = iperarchi, colonne = nodi)
    mat_e_testa_di = zeros(num_iperarchi, N);
    mat_e_coda_di = zeros(num_iperarchi, N);
    
    % Vettore di supporto per salvare il tipo di iperarco:
    % 1 = "1 testa, 2 code" (standard)
    % 2 = "2 teste, 1 coda" (invertito)
    tipo_iperarco = zeros(num_iperarchi, 1);
    
    id_arco = 1; % Contatore per l'indice dell'iperarco corrente
    
    % 1. Generazione della struttura regolare iniziale
    for i = 1:N
        for dist = 1:num_vicini
            
            % Calcola i vicini simmetrici a distanza 'dist' con logica circolare
            vicino_sinistro = mod(i - 1 - dist, N) + 1;
            vicino_destro = mod(i - 1 + dist, N) + 1;
            
            % Alternanza: invertiamo un iperarco ogni due (quelli con id_arco dispari o pari)
            % In questo modo, il 50% degli iperarchi viene invertito.
            if mod(id_arco, f) == 1
                % --- STRUTTURA STANDARD: 1 Testa, 2 Code ---
                tipo_iperarco(id_arco) = 1;
                
                mat_e_testa_di(id_arco, i) = i;
                mat_e_coda_di(id_arco, vicino_sinistro) = vicino_sinistro;
                mat_e_coda_di(id_arco, vicino_destro) = vicino_destro;
            else
                % --- STRUTTURA INVERTITA: 2 Teste, 1 Coda ---
                tipo_iperarco(id_arco) = 2;
                
                % Invertiamo la logica: i vicini diventano teste, il nodo i diventa coda
                mat_e_testa_di(id_arco, vicino_sinistro) = vicino_sinistro;
                mat_e_testa_di(id_arco, vicino_destro) = vicino_destro;
                mat_e_coda_di(id_arco, i) = i;
            end
            
            id_arco = id_arco + 1;
        end
    end
    
    % 2. Fase di Rewiring (Riconnessione casuale con probabilità p)
    for id_arco = 1:num_iperarchi
        if rand < p
            
            if tipo_iperarco(id_arco) == 1
                % --- REWIRING STANDARD (Mantiene 1 Testa e cambia 2 Code) ---
                nodo_testa = find(mat_e_testa_di(id_arco, :), 1);
                
                % Azzera le code correnti
                mat_e_coda_di(id_arco, :) = 0;
                
                % Estrae due nuove code casuali diverse dalla testa
                code_nuove = randperm(N, 2);
                while any(code_nuove == nodo_testa)
                    code_nuove = randperm(N, 2);
                end
                
                % Assegna le nuove code
                mat_e_coda_di(id_arco, code_nuove) = code_nuove;
                
            else
                % --- REWIRING INVERTITO (Mantiene 1 Coda e cambia 2 Teste) ---
                nodo_coda = find(mat_e_coda_di(id_arco, :), 1);
                
                % Azzera le teste correnti
                mat_e_testa_di(id_arco, :) = 0;
                
                % Estrae due nuove teste casuali diverse dalla coda
                teste_nuove = randperm(N, 2);
                while any(teste_nuove == nodo_coda)
                    teste_nuove = randperm(N, 2);
                end
                
                % Assegna le nuove teste
                mat_e_testa_di(id_arco, teste_nuove) = teste_nuove;
            end
            
        end
    end
end