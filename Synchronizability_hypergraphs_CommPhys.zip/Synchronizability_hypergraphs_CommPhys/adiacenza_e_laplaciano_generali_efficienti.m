function [L,A,A_piu] = adiacenza_e_laplaciano_generali_efficienti(mat_e_testa_di, mat_e_coda_di, N, vettore_sigma)

    A=zeros(N,N);
    A_piu=zeros(N,N);

    n_iperarchi=size(mat_e_testa_di,1);

    for i=1:n_iperarchi

        teste=nonzeros(mat_e_testa_di(i,:));
        code=nonzeros(mat_e_coda_di(i,:));

        n_teste=size(teste,1);
        n_code=size(code,1);

        cardinalita_iperarco=n_code+n_teste;

        for j=1:n_teste  %Gestisco i pesi negativi (testa-testa)

            for k=1:n_teste

                if j ~= k

                    A(teste(j),teste(k))=A(teste(j),teste(k))-1/n_teste*vettore_sigma(cardinalita_iperarco-1);

                end

            end

        end

        for j=1:n_code  %Gestisco i pesi positivi (coda-testa)

            for k=1:n_teste

                A(teste(k),code(j))=A(teste(k),code(j))+1/n_code*vettore_sigma(cardinalita_iperarco-1);
                A_piu(teste(k),code(j))=A(teste(k),code(j))+1/n_code*vettore_sigma(cardinalita_iperarco-1);

            end

        end

    end

    L=diag(sum(A,2))-A;

end