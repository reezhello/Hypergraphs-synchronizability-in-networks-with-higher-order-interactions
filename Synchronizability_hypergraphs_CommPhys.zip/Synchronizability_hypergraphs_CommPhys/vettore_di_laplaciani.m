function vett_L = vettore_di_laplaciani(mat_e_testa_di, mat_e_coda_di, N, gamma, n, card)

    vett_L=zeros(n*N,n*N,size(mat_e_testa_di,1));

    for i=1:size(mat_e_testa_di,1)

        [L,~]=adiacenza_e_laplaciano_generali_efficienti(mat_e_testa_di(i,:), mat_e_coda_di(i,:), N, ones(1,card));
        vett_L(:,:,i)=kron(L,gamma);

    end

end