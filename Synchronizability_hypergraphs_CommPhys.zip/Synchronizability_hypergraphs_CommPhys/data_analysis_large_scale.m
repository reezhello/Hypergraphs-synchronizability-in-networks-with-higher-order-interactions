clear 
close all 
clc

n_topologie_gruppo=100;
n_gruppi=4;

set(groot,'defaultAxesTickLabelInterpreter','latex')
set(groot,'defaultTextInterpreter','latex')

matrice_stim_kur=zeros(n_topologie_gruppo,n_gruppi);
matrice_eff_kur=zeros(n_topologie_gruppo,n_gruppi);
matrice_S_kur=zeros(n_topologie_gruppo,n_gruppi);
quante_reti_non_sincronizzano=zeros(1,n_gruppi);

load('gra_large_scale_100_200_500_1000_kur.mat')
GRAFI=RISULTATI_FINALI;
load('hyp_large_scale_sink_100_200_500_1000_kur.mat')
SINK=RISULTATI_FINALI;
load('hyp_large_scale_source_100_200_500_kur.mat')
SOURCE=RISULTATI_FINALI;
load('hyp_large_scale_source_1000_kur.mat')
SOURCE=[SOURCE RISULTATI_FINALI];

matrice_stim_kur_sink=zeros(n_topologie_gruppo,n_gruppi);
matrice_eff_kur_sink=zeros(n_topologie_gruppo,n_gruppi);
matrice_S_kur_sink=zeros(n_topologie_gruppo,n_gruppi);
quante_reti_non_sincronizzano_sink=zeros(1,n_gruppi);

matrice_stim_kur_source=zeros(n_topologie_gruppo,n_gruppi);
matrice_eff_kur_source=zeros(n_topologie_gruppo,n_gruppi);
matrice_S_kur_source=zeros(n_topologie_gruppo,n_gruppi);
quante_reti_non_sincronizzano_source=zeros(1,n_gruppi);

matrice_stim_kur_grafi=zeros(n_topologie_gruppo,n_gruppi);
matrice_eff_kur_grafi=zeros(n_topologie_gruppo,n_gruppi);
matrice_S_kur_grafi=zeros(n_topologie_gruppo,n_gruppi);
quante_reti_non_sincronizzano_grafi=zeros(1,n_gruppi);

vettore_laplaciani_mal_condizionati=zeros(1,n_gruppi);

for j=1:n_gruppi
    gruppo_sink=SINK{j};
    gruppo_source=SOURCE{j};
    gruppo_grafi=GRAFI{j};
    for i=1:n_topologie_gruppo
    
        matrice_eff_kur_sink(i,j)=gruppo_sink(i).bound_effettivo;
        matrice_stim_kur_sink(i,j)=gruppo_sink(i).bound_stimato;
        matrice_S_kur_sink(i,j)=(gruppo_sink(i).bound_stimato/(gruppo_sink(i).numero_nodi)^(1/2))^(-1);
        if gruppo_sink(i).condition_number>2000
            vettore_laplaciani_mal_condizionati(j)=vettore_laplaciani_mal_condizionati(j)+1;
            matrice_eff_kur_sink(i,j)=NaN;
            matrice_stim_kur_sink(i,j)=NaN;
            matrice_S_kur_sink(i,j)=NaN;
        end

        matrice_eff_kur_source(i,j)=gruppo_source(i).bound_effettivo;
        matrice_stim_kur_source(i,j)=gruppo_source(i).bound_stimato;
        matrice_S_kur_source(i,j)=(gruppo_source(i).bound_stimato/(gruppo_source(i).numero_nodi)^(1/2))^(-1);

        matrice_eff_kur_grafi(i,j)=gruppo_grafi(i).bound_effettivo;
        matrice_stim_kur_grafi(i,j)=gruppo_grafi(i).bound_stimato;
        matrice_S_kur_grafi(i,j)=(gruppo_grafi(i).bound_stimato/(gruppo_grafi(i).numero_nodi)^(1/2))^(-1);
    
    end
end

vettore_S_medie_grafi=mean(matrice_S_kur_grafi,1);
vettore_S_medie_source=mean(matrice_S_kur_source,1);
vettore_S_medie_sink=mean(matrice_S_kur_sink,1,"omitnan");
vettore_S_medie=mean(matrice_S_kur,1);

deviazioni_S_grafi = std(matrice_S_kur_grafi, 0, 1);
deviazioni_S_source = std(matrice_S_kur_source, 0, 1);
deviazioni_S = std(matrice_S_kur, 0, 1);
deviazioni_S_sink=std(matrice_S_kur_sink, 0, 1,"omitnan");

vettore_pearson_sink=zeros(1,n_gruppi);
vettore_kendall_sink=zeros(1,n_gruppi);
vettore_rquadro_sink=zeros(1,n_gruppi);
matrice_parametri_sink=zeros(2,n_gruppi);

vettore_pearson_source=zeros(1,n_gruppi);
vettore_kendall_source=zeros(1,n_gruppi);
vettore_rquadro_source=zeros(1,n_gruppi);
matrice_parametri_source=zeros(2,n_gruppi);

vettore_pearson_grafi=zeros(1,n_gruppi);
vettore_kendall_grafi=zeros(1,n_gruppi);
vettore_rquadro_grafi=zeros(1,n_gruppi);
matrice_parametri_grafi=zeros(2,n_gruppi);

for i=1:n_gruppi

    vettore_stim=matrice_stim_kur_sink(:,i);
    vettore_eff=matrice_eff_kur_sink(:,i);
    vettore_S=matrice_S_kur_sink(:,i);

    vettore_stim=vettore_stim(~isnan(vettore_stim));
    vettore_eff=vettore_eff(~isnan(vettore_eff));
    vettore_S=vettore_S(~isnan(vettore_S));

    mdl_kur_sink=fitlm(vettore_eff,vettore_stim); 
    vettore_pearson_sink(i)=corr(vettore_eff,vettore_stim);
    vettore_kendall_sink(i)=corr(vettore_eff,vettore_stim,"Type","Kendall");
    vettore_rquadro_sink(i)=mdl_kur_sink.Rsquared.Ordinary;
    matrice_parametri_sink(:,i)=mdl_kur_sink.Coefficients.Estimate;

    mdl_kur_source=fitlm(matrice_eff_kur_source(:,i),matrice_stim_kur_source(:,i)); 
    vettore_pearson_source(i)=corr(matrice_eff_kur_source(:,i),matrice_stim_kur_source(:,i));
    vettore_kendall_source(i)=corr(matrice_eff_kur_source(:,i),matrice_stim_kur_source(:,i),"Type","Kendall");
    vettore_rquadro_source(i)=mdl_kur_source.Rsquared.Ordinary;
    matrice_parametri_source(:,i)=mdl_kur_source.Coefficients.Estimate;

    mdl_kur_grafi=fitlm(matrice_eff_kur_grafi(:,i),matrice_stim_kur_grafi(:,i)); 
    vettore_pearson_grafi(i)=corr(matrice_eff_kur_grafi(:,i),matrice_stim_kur_grafi(:,i));
    vettore_kendall_grafi(i)=corr(matrice_eff_kur_grafi(:,i),matrice_stim_kur_grafi(:,i),"Type","Kendall");
    vettore_rquadro_grafi(i)=mdl_kur_grafi.Rsquared.Ordinary;
    matrice_parametri_grafi(:,i)=mdl_kur_grafi.Coefficients.Estimate;

end





