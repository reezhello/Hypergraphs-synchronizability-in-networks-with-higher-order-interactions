clear all 
close all 
clc

n_topologie_gruppo=100;
n_gruppi=3;

load("hyp_deg_cresc_kur_100top_eps1_v1.mat");
KUR=RISULTATI_FINALI;
gruppo_kur12=KUR{3};

load("hyp_deg_cresc_ross_100top_eps1_v1.mat");
ROSS=RISULTATI_FINALI;
gruppo_ross12=ROSS{3};

load("hyp_deg_cresc_kur_100top_eps1_v1.mat");
KUR=RISULTATI_FINALI;
gruppo_kur16=KUR{5};

load("hyp_deg_cresc_ross_100top_eps1_v1.mat");
ROSS=RISULTATI_FINALI;
gruppo_ross16=ROSS{5};

load("hyp_deg_8_kur_100top_eps1_cond_num_Kendall.mat");
KUR=RISULTATI_FINALI;
gruppo_kur8=KUR{1};

load("hyp_deg_8_ross_100top_eps1_cond_num_Kendall.mat");
ROSS=RISULTATI_FINALI;
gruppo_ross8=ROSS{1};

set(groot,'defaultAxesTickLabelInterpreter','latex')
set(groot,'defaultTextInterpreter','latex')

vettore_stim_kur12=zeros(n_topologie_gruppo,1);
vettore_eff_kur12=zeros(n_topologie_gruppo,1);

vettore_stim_ross12=zeros(n_topologie_gruppo,1);
vettore_eff_ross12=zeros(n_topologie_gruppo,1);

vettore_stim_kur16=zeros(n_topologie_gruppo,1);
vettore_eff_kur16=zeros(n_topologie_gruppo,1);

vettore_stim_ross16=zeros(n_topologie_gruppo,1);
vettore_eff_ross16=zeros(n_topologie_gruppo,1);

vettore_stim_kur8=zeros(n_topologie_gruppo,1);
vettore_eff_kur8=zeros(n_topologie_gruppo,1);

vettore_stim_ross8=zeros(n_topologie_gruppo,1);
vettore_eff_ross8=zeros(n_topologie_gruppo,1);

for i=1:n_topologie_gruppo

    vettore_eff_kur12(i)=gruppo_kur12(i).bound_effettivo;
    vettore_eff_ross12(i)=gruppo_ross12(i).bound_effettivo;

    vettore_stim_kur12(i)=gruppo_kur12(i).bound_stimato;
    vettore_stim_ross12(i)=gruppo_ross12(i).bound_stimato;

    vettore_eff_kur16(i)=gruppo_kur16(i).bound_effettivo;
    vettore_eff_ross16(i)=gruppo_ross16(i).bound_effettivo;

    vettore_stim_kur16(i)=gruppo_kur16(i).bound_stimato;
    vettore_stim_ross16(i)=gruppo_ross16(i).bound_stimato;

    vettore_eff_kur8(i)=gruppo_kur8(i).bound_effettivo;
    vettore_eff_ross8(i)=gruppo_ross8(i).bound_effettivo;

    vettore_stim_kur8(i)=gruppo_kur8(i).bound_stimato;
    vettore_stim_ross8(i)=gruppo_ross8(i).bound_stimato;

end

set(groot,'defaultAxesTickLabelInterpreter','latex')
set(groot,'defaultTextInterpreter','latex')

mdl_kur_12=fitlm(vettore_eff_kur12,vettore_stim_kur12); %Correlazioni "a pezzi" grado 12
ro12kur=corr(vettore_eff_kur12,vettore_stim_kur12)
ro12kur_kendall=corr(vettore_eff_kur12,vettore_stim_kur12,"Type","Kendall")
R_quadro_12kur=mdl_kur_12.Rsquared
parametri_12kur=mdl_kur_12.Coefficients.Estimate;

mdl_ross_12=fitlm(vettore_eff_ross12,vettore_stim_ross12);
ro12ross=corr(vettore_eff_ross12,vettore_stim_ross12)
ro12ross_kendall=corr(vettore_eff_ross12,vettore_stim_ross12,"Type","Kendall")
R_quadro_12ross=mdl_ross_12.Rsquared
parametri_12ross=mdl_ross_12.Coefficients.Estimate;

mdl_kur_16=fitlm(vettore_eff_kur16,vettore_stim_kur16); %Correlazioni a pezzi grado 16
ro16kur=corr(vettore_eff_kur16,vettore_stim_kur16)
ro16kur_kendall=corr(vettore_eff_kur16,vettore_stim_kur16,"Type","Kendall")
R_quadro_16kur=mdl_kur_16.Rsquared
parametri_16kur=mdl_kur_16.Coefficients.Estimate;

mdl_ross_16=fitlm(vettore_eff_ross16,vettore_stim_ross16);
ro16ross=corr(vettore_eff_ross16,vettore_stim_ross16)
ro16ross_kendall=corr(vettore_eff_ross16,vettore_stim_ross16,"Type","Kendall")
R_quadro_16ross=mdl_ross_16.Rsquared
parametri_16ross=mdl_ross_16.Coefficients.Estimate;

mdl_kur_8=fitlm(vettore_eff_kur8,vettore_stim_kur8); %Correlazioni a pezzi grado 8
ro8kur=corr(vettore_eff_kur8,vettore_stim_kur8)
ro8kur_kendall=corr(vettore_eff_kur8,vettore_stim_kur8,"Type","Kendall")
R_quadro_8kur=mdl_kur_8.Rsquared
parametri_8kur=mdl_kur_8.Coefficients.Estimate;

mdl_ross_8=fitlm(vettore_eff_ross8,vettore_stim_ross8);
ro8ross=corr(vettore_eff_ross8,vettore_stim_ross8)
ro8ross_kendall=corr(vettore_eff_ross8,vettore_stim_ross8,"Type","Kendall")
R_quadro_8ross=mdl_ross_8.Rsquared
parametri_8ross=mdl_ross_8.Coefficients.Estimate;

%Creo i vettori complessivi

vettore_stim_tot_kur=[vettore_stim_kur12; vettore_stim_kur16; vettore_stim_kur8];
vettore_eff_tot_kur=[vettore_eff_kur12; vettore_eff_kur16; vettore_eff_kur8];

vettore_stim_tot_ross=[vettore_stim_ross12; vettore_stim_ross16; vettore_stim_ross8];
vettore_eff_tot_ross=[vettore_eff_ross12; vettore_eff_ross16; vettore_eff_ross8];

mdl_tot_kur=fitlm(vettore_eff_tot_kur,vettore_stim_tot_kur);
ro_tot_kur=corr(vettore_eff_tot_kur,vettore_stim_tot_kur)
ro_tot_kur_kendall=corr(vettore_eff_tot_kur,vettore_stim_tot_kur,"Type","Kendall")
R_quadro_tot_kur=mdl_tot_kur.Rsquared
parametri_tot_kur=mdl_tot_kur.Coefficients.Estimate;

mdl_tot_ross=fitlm(vettore_eff_tot_ross,vettore_stim_tot_ross);
ro_tot_ross=corr(vettore_eff_tot_ross,vettore_stim_tot_ross)
ro_tot_ross_kendall=corr(vettore_eff_tot_ross,vettore_stim_tot_ross,"Type","Kendall")
R_quadro_tot_ross=mdl_tot_ross.Rsquared
parametri_tot_ross=mdl_tot_ross.Coefficients.Estimate;

a=6;
subplot(1,2,1)
plot(vettore_eff_kur12,vettore_stim_kur12,'d','MarkerSize',a); 
hold on
plot(vettore_eff_kur16,vettore_stim_kur16,'d','MarkerSize',a); 
hold on 
plot(vettore_eff_kur8,vettore_stim_kur8,'d','MarkerSize',a); 
title('Kuramoto model')
hold on
x1=[0:0.01:1];
y1=parametri_tot_kur(1)+parametri_tot_kur(2)*x1;
plot(x1,y1,"LineStyle","--","Color","k",'LineWidth',1.25);
xlabel("$c$")
ylabel("$\hat c$")
limx=[0 0.8];
xlim(limx)
limy=[0 0.8];
ylim(limy)
xticks(0:0.2:0.8)
yticks(0:0.2:0.8)
xticklabels(0:0.02:0.08)
yticklabels(0:0.02:0.08) %Sto dividendo per la radice di 100
set(gca,'FontSize',15)

subplot(1,2,2)
plot(vettore_eff_ross12,vettore_stim_ross12,'d','MarkerSize',a);
hold on
plot(vettore_eff_ross16,vettore_stim_ross16,'d','MarkerSize',a);
hold on
plot(vettore_eff_ross8,vettore_stim_ross8,'d','MarkerSize',a);
title('Coupled R\"ossler systems')
hold on
x2=[0:0.01:13];
y2=parametri_tot_ross(1)+parametri_tot_ross(2)*x2;
plot(x2,y2,"LineStyle","--","Color","k",'LineWidth',1.25);
hold on
text(0.08,-0.022,'$(\times10^{-3})$','FontSize',11)
text(-0.015,0.13,'$(\times10^{-3})$','FontSize',11)
xlabel("$c$")
ylabel("$\hat c$")
limx=[0 0.1];
xlim(limx)
limy=[0 0.12];
ylim(limy)
xticks(0:0.02:0.1)
xtickangle(0)
yticks(0:0.03:0.12)
xticklabels(0:2:10);
yticklabels(0:3:100);
% ax=gca
% ax.YAxis.Exponent=-3
% ax.XAxis.Exponent=-3


set(gca,'FontSize',15)

set(gcf, 'Position',  [250, 125, 825, 300]);


