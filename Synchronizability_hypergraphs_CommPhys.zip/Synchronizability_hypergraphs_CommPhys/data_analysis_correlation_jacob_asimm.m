clear all 
close all 
clc

n_topologie_gruppo=100;
n_gruppi=3;

load("hyp_deg_8_12_16_ross_100_top_eps1_jacob_asimm.mat");
ROSS=RISULTATI_FINALI;

gruppo_ross8=ROSS{1};
gruppo_ross12=ROSS{2};
gruppo_ross16=ROSS{3};

set(groot,'defaultAxesTickLabelInterpreter','latex')
set(groot,'defaultTextInterpreter','latex')

vettore_stim_ross8=zeros(n_topologie_gruppo,1);
vettore_eff_ross8=zeros(n_topologie_gruppo,1);

vettore_stim_ross12=zeros(n_topologie_gruppo,1);
vettore_eff_ross12=zeros(n_topologie_gruppo,1);

vettore_stim_ross16=zeros(n_topologie_gruppo,1);
vettore_eff_ross16=zeros(n_topologie_gruppo,1);

for i=1:n_topologie_gruppo

    vettore_eff_ross8(i)=gruppo_ross8(i).bound_effettivo;
    vettore_stim_ross8(i)=gruppo_ross8(i).bound_stimato;

    vettore_eff_ross12(i)=gruppo_ross12(i).bound_effettivo;
    vettore_stim_ross12(i)=gruppo_ross12(i).bound_stimato;

    vettore_eff_ross16(i)=gruppo_ross16(i).bound_effettivo;
    vettore_stim_ross16(i)=gruppo_ross16(i).bound_stimato;

end

set(groot,'defaultAxesTickLabelInterpreter','latex')
set(groot,'defaultTextInterpreter','latex')

mdl_ross_8=fitlm(vettore_eff_ross8,vettore_stim_ross8);
ro8ross=corr(vettore_eff_ross8,vettore_stim_ross8)
ro8ross_kendall=corr(vettore_eff_ross8,vettore_stim_ross8,"Type","Kendall")
R_quadro_8ross=mdl_ross_8.Rsquared
parametri_8ross=mdl_ross_8.Coefficients.Estimate;

mdl_ross_12=fitlm(vettore_eff_ross12,vettore_stim_ross12);
ro12ross=corr(vettore_eff_ross12,vettore_stim_ross12)
ro12ross_kendall=corr(vettore_eff_ross12,vettore_stim_ross12,"Type","Kendall")
R_quadro_12ross=mdl_ross_12.Rsquared
parametri_12ross=mdl_ross_12.Coefficients.Estimate;

mdl_ross_16=fitlm(vettore_eff_ross16,vettore_stim_ross16);
ro16ross=corr(vettore_eff_ross16,vettore_stim_ross16)
ro16ross_kendall=corr(vettore_eff_ross16,vettore_stim_ross16,"Type","Kendall")
R_quadro_16ross=mdl_ross_16.Rsquared
parametri_16ross=mdl_ross_16.Coefficients.Estimate;

%Creo i vettori complessivi

vettore_stim_tot_ross=[vettore_stim_ross8; vettore_stim_ross12; vettore_stim_ross16];
vettore_eff_tot_ross=[vettore_eff_ross8; vettore_eff_ross12; vettore_eff_ross16];

mdl_tot_ross=fitlm(vettore_eff_tot_ross,vettore_stim_tot_ross);
ro_tot_ross=corr(vettore_eff_tot_ross,vettore_stim_tot_ross)
ro_tot_ross_kendall=corr(vettore_eff_tot_ross,vettore_stim_tot_ross,"Type","Kendall")
R_quadro_tot_ross=mdl_tot_ross.Rsquared
parametri_tot_ross=mdl_tot_ross.Coefficients.Estimate;

a=6;

figure
plot(vettore_eff_ross12,vettore_stim_ross12,'d','MarkerSize',a);
hold on
plot(vettore_eff_ross16,vettore_stim_ross16,'d','MarkerSize',a);
hold on
plot(vettore_eff_ross8,vettore_stim_ross8,'d','MarkerSize',a);
title('Coupled R\"ossler systems')
hold on
x2=[0:0.01:13];
y2=parametri_tot_ross(1)+parametri_tot_ross(2)*x2;
plot(x2,y2,"LineStyle","--","Color","k",'LineWidth',1.25);
hold on
text(0.055,-0.013,'$(\times10^{-3})$','FontSize',11)
text(-0.009,0.083,'$(\times10^{-3})$','FontSize',11)
xlabel("$c$")
ylabel("$\hat c$")
limx=[0 0.0600001];
xlim(limx)
limy=[0 0.09];
ylim(limy)
xticks(0:0.02:0.1)
xtickangle(0)
yticks(0:0.03:0.12)
xticklabels(0:2:10);
yticklabels(0:3:100);


set(gca,'FontSize',15)
%525 350

set(gcf, 'Position',  [250, 125, 525, 350]);


