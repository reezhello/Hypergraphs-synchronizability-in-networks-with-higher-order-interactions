clear all 
close all 
clc

n_topologie_gruppo=100;
n_gruppi=3;

load("hyp_kur_small_world.mat");
KUR=RISULTATI_FINALI;
gruppo_kur01=KUR{1};

load("hyp_ross_small_world.mat")
ROSS=RISULTATI_FINALI;
gruppo_ross01=ROSS{1};

set(groot,'defaultAxesTickLabelInterpreter','latex')
set(groot,'defaultTextInterpreter','latex')

vettore_stim_kur01=zeros(n_topologie_gruppo,1);
vettore_eff_kur01=zeros(n_topologie_gruppo,1);

vettore_stim_ross01=zeros(n_topologie_gruppo,1);
vettore_eff_ross01=zeros(n_topologie_gruppo,1);

for i=1:n_topologie_gruppo

    vettore_eff_kur01(i)=gruppo_kur01(i).bound_effettivo/gruppo_kur01(i).numero_nodi;

    vettore_stim_kur01(i)=gruppo_kur01(i).bound_stimato/gruppo_kur01(i).numero_nodi;

    vettore_eff_ross01(i)=gruppo_ross01(i).bound_effettivo/gruppo_ross01(i).numero_nodi;

    vettore_stim_ross01(i)=gruppo_ross01(i).bound_stimato/gruppo_ross01(i).numero_nodi;

end

set(groot,'defaultAxesTickLabelInterpreter','latex')
set(groot,'defaultTextInterpreter','latex')

mdl_kur_01=fitlm(vettore_eff_kur01,vettore_stim_kur01); %Correlazioni "a pezzi"
ro01kur=corr(vettore_eff_kur01,vettore_stim_kur01)
ro01kur_kendall=corr(vettore_eff_kur01,vettore_stim_kur01,"Type","Kendall")
R_quadro_01kur=mdl_kur_01.Rsquared
parametri_01kur=mdl_kur_01.Coefficients.Estimate;

mdl_ross_01=fitlm(vettore_eff_ross01,vettore_stim_ross01); %Correlazioni a pezzi 
ro01ross=corr(vettore_eff_ross01,vettore_stim_ross01)
ro01ross_kendall=corr(vettore_eff_ross01,vettore_stim_ross01,"Type","Kendall")
R_quadro_01ross=mdl_ross_01.Rsquared
parametri_01ross=mdl_ross_01.Coefficients.Estimate;

a=6;
subplot(1,2,1)
plot(vettore_eff_kur01,vettore_stim_kur01,'d','MarkerSize',a); 
title('Kuramoto model')
hold on
x1=[0:0.01:1];
y1=parametri_01kur(1)+parametri_01kur(2)*x1;
plot(x1,y1,"LineStyle","--","Color","k",'LineWidth',1.25);
xlabel("$c$")
ylabel("$\hat c$")
limx=[0 0.02];
xlim(limx)
limy=[0 0.02];
ylim(limy)
xticks(0:0.005:0.02)
yticks(0:0.005:0.02)
xticklabels(0:0.005:0.02)
yticklabels(0:0.005:0.02) 
set(gca,'FontSize',15)

subplot(1,2,2)
plot(vettore_eff_ross01,vettore_stim_ross01,'d','MarkerSize',a); 
title('R\"ossler systems')
hold on
x1=[0:0.001:1];
y1=parametri_01ross(1)+parametri_01ross(2)*x1;
plot(x1,y1,"LineStyle","--","Color","k",'LineWidth',1.25);
xlabel("$c$")
ylabel("$\hat c$")
limx=[0 0.003];
xlim(limx)
limy=[-0.001 0.015];
ylim(limy)
xticks(0:0.001:0.003)
yticks(0:0.005:0.015)
xticklabels(0:0.001:0.003)
yticklabels(0:0.005:0.015) 
set(gca,'FontSize',15)

set(gcf, 'Position',  [250, 125, 825, 300]);


