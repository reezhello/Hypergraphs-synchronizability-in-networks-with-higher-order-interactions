clear all 
close all 
clc

n_gruppi=9; %Numero di elementi nel vettore n_oggetti_imposti
RISULTATI_FINALI=cell(1,n_gruppi);

n_topologie=100;

load("set_100_top.mat")

%Dati dimensionali del Rossler
n=3;
p=3;
an=0.2;
bn=0.2;
cn=5.6;

par_nom=[an bn cn];

%Dati dimensionali della rete desiderata

N=100;

sigma=[1 2 5 10 20 50 100 200 500];
norma_imposta_di_delta_mu=1;

card=3;

% Variazioni parametriche

delta_mu=zeros(p,N);

for k=1:p

    for i=1:N

        delta_mu(k,i)=unifrnd(-norma_imposta_di_delta_mu*par_nom(k),par_nom(k)*norma_imposta_di_delta_mu);

    end

end

delta_mu=[delta_mu(1,:) delta_mu(2,:) delta_mu(3,:)];

delta_mu=delta_mu/norm(delta_mu)*norma_imposta_di_delta_mu;

delta_mu=[delta_mu(1:N); delta_mu(N+1:2*N); delta_mu(2*N+1:3*N)];

PAR=delta_mu+kron(ones(1,N),par_nom');

for D=1:n_gruppi

simulazioni_buone=1;

vettore_bound_effettivi=zeros(n_topologie,1);
vettore_bound_stimati=zeros(n_topologie,1);

sigma_v=sigma(D)*ones(1,3);

while simulazioni_buone<=n_topologie

    D
    simulazioni_buone

    mat_e_testa_di=topologie(simulazioni_buone).mat_teste;
    mat_e_coda_di=topologie(simulazioni_buone).mat_code;

    %Verifico il grado medio della rete generata
    d_out_medio=calcolo_grado_medio(mat_e_coda_di)  
    d_in_medio=calcolo_grado_medio(mat_e_testa_di)

    %Calcolo il numero di iperarchi

    n_iperarchi=size(mat_e_testa_di,1);
    
    %Preparo il necessario per la simulazione
    [L_tra_media, A_tra_media]=adiacenza_e_laplaciano_generali_efficienti(mat_e_testa_di, mat_e_coda_di, N, sigma_v);
    
    %Condizioni iniziali tutte nulle (parto sincronizzato)
    x0=zeros(p,N);
    
    fun = @(t,x) rossler_veloce(x, PAR, N, n, L_tra_media);
    Tf = 250;
    
    [t, x]=ode23tb(fun,[0 Tf],x0);

    tra_media=zeros(size(t,1),n);

    for i=1:size(t,1)

        for j=1:n

            tra_media(i,j)=mean(x(i,j:n:n*N));

        end

    end

    s=tra_media; 

    % %Plot
    % set(groot,'defaultAxesTickLabelInterpreter','latex')
    % set(groot,'defaultTextInterpreter','latex')
    % figure
    % subplot(3,1,1)
    % plot(t,x(:,1:3:end),'LineWidth',1)
    % xlabel('$t$')
    % ylabel('$x_{i,1}(t)$')
    % subplot(3,1,2)
    % plot(t,x(:,2:3:end),'LineWidth',1)
    % xlabel('$t$')
    % ylabel('$x_{i,2}(t)$')
    % subplot(3,1,3)
    % plot(t,x(:,3:3:end),'LineWidth',1)
    % xlabel('$t$')
    % ylabel('$x_{i,3}(t)$')
    % 
    % %Plot errore
    % set(groot,'defaultAxesTickLabelInterpreter','latex')
    % set(groot,'defaultTextInterpreter','latex')
    % figure
    % subplot(3,1,1)
    % plot(t,x(:,1:3:end)-s(:,end-2).*ones(1,N),'LineWidth',1)
    % xlabel('$t$')
    % ylabel('$e_{i,1}(t)$')
    % subplot(3,1,2)
    % plot(t,x(:,2:3:end)-s(:,end-1).*ones(1,N),'LineWidth',1)
    % xlabel('$t$')
    % ylabel('$e_{i,2}(t)$')
    % subplot(3,1,3)
    % plot(t,x(:,3:3:end)-s(:,end).*ones(1,N),'LineWidth',1)
    % xlabel('$t$')
    % ylabel('$e_{i,3}(t)$')
        
    norma_err_tv=zeros(1,size(t,1));
    regime_ottenuto=1;
    
    %Calcolo della norma dell'errore
    for u=1:size(t,1)
      
        norma_err_tv(u)=norm(x(u,1:N*n)-kron(ones(1,N),s(u,:)));
       
    end
    
    %Calcolo dell'istante in cui la norma dell'errore ha raggiunto il
    %regime
    for u=2:size(t,1)
    
        if (norma_err_tv(u)-norma_err_tv(u-1))/(t(u)-t(u-1))>=0
    
            regime_ottenuto=u;
            break
    
        end
    
    end

    %Stimo il bound usando una stima della traiettoria media

    %Calcolo della traiettoria esplorativa (stima della traiettoria
    %media)

    x0_esp=[0 0 0]; %Avrei dovuto predere le condizioni iniziali medie, ma la media tra tanti zeri è zero

    par_medi=mean(PAR,2);

    fun1 = @(t,x) stima_traiettoria_media_rossler(x, par_medi(1), par_medi(2), par_medi(3));
    [~,stima_traiettoria_media]=ode23tb(fun1,[0 Tf],x0_esp);

    [bound_stimato,L_u_bar]=calcolo_bound_rossler_sincronizzazione_VELOCE(n,N,p,par_medi, stima_traiettoria_media, mat_e_testa_di, mat_e_coda_di, PAR, sigma_v);

    condizionamento=cond(L_u_bar);

    % %Plot norma errore e bound stimato
    % set(groot,'defaultAxesTickLabelInterpreter','latex')
    % set(groot,'defaultTextInterpreter','latex')
    % figure
    % plot(t,norma_err_tv(:))
    % xlabel('$t$')
    % ylabel('$\|\delta x(t)\|$')
    % title('Error Vector Norm Temporal Evolution')
    % xlim([0, Tf]);
    % ylim([-bound_stimato, 2*bound_stimato]);
    % hold on 
    % plot(t,bound_stimato*ones(size(t)),'--r','LineWidth',2)
    % legend({'$\|\delta x(t)\|$','$B$'},'Interpreter','latex')

    %Calcolo del bound effettivo
    bound_effettivo=max(norma_err_tv(regime_ottenuto:end));

    %Il bound stimato è rispettato?
    if bound_effettivo<bound_stimato

        rispetto_bound_stimato=1;

    else

        rispetto_bound_stimato=0;

    end

    vettore_bound_effettivi(simulazioni_buone)=bound_effettivo;
    vettore_bound_stimati(simulazioni_buone)=bound_stimato;

        %Salvataggio dei risultati nella struct
        risultati(simulazioni_buone).grado_medio_out=d_out_medio;
        risultati(simulazioni_buone).grado_medio_in=d_in_medio;
        risultati(simulazioni_buone).simmetria_rete_a_ciclo_aperto=0;
        risultati(simulazioni_buone).numero_nodi=N;
        risultati(simulazioni_buone).vettore_sigma=sigma_v;
        risultati(simulazioni_buone).bound_effettivo=bound_effettivo;
        risultati(simulazioni_buone).bound_stimato=bound_stimato;
        risultati(simulazioni_buone).bound_rispettato=rispetto_bound_stimato;
        % risultati(simulazioni_buone).numero_oggetti=n_oggetti_imposti(D);
        risultati(simulazioni_buone).condition_number=condizionamento;
        risultati(simulazioni_buone).card_iperarchi=card;
    
        simulazioni_buone=simulazioni_buone+1;

end

correlazione_tra_bound=corr(vettore_bound_effettivi,vettore_bound_stimati);
risultati(1).correlazione_Pearson=correlazione_tra_bound;

correlazione_tra_bound=corr(vettore_bound_effettivi,vettore_bound_stimati,"Type","Kendall");
risultati(1).correlazione_Kendall=correlazione_tra_bound;

ranking_reale=vettore_ranking(vettore_bound_effettivi');
risultati(1).classifica_reale=ranking_reale;

ranking_stimato=vettore_ranking(vettore_bound_stimati');
risultati(1).classifica_stimata=ranking_stimato;

RISULTATI_FINALI{D}=risultati;

end

%Comando save

%save("REV_ROSSLER_sigma_stesso_set_top","RISULTATI_FINALI")

%Funzioni per usare ode

function xdotF = rossler_veloce(x, PAR, N, n, L)

    xdotF = kron(-x(2:n:n*N)-x(3:n:n*N), [1 0 0]') +...
            kron(x(1:n:n*N)+PAR(1,1:N)'.*x(2:n:n*N), [0 1 0]') +...
            kron(PAR(2,1:N)'+x(3:n:n*N).*(x(1:n:n*N)-PAR(3,1:N)'), [0 0 1]') -...
            kron(L,eye(n,n))*x;
            
end

function xdotF = stima_traiettoria_media_rossler(x, a_medio, b_medio, c_medio)

    xdotF = [-x(2)-x(3); ...
            x(1)+a_medio*x(2);...
            b_medio+x(3)*(x(1)-c_medio)];
end