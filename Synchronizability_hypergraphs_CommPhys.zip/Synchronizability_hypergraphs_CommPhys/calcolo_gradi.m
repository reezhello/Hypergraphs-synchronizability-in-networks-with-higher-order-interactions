function vettore_gradi = calcolo_gradi(matrice)
    
    matrice_binaria=matrice~=0;

    vettore_gradi=sum(matrice_binaria,1);

end