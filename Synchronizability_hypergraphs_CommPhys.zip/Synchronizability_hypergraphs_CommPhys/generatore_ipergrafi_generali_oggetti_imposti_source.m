function [mat_e_testa_di_def, mat_e_coda_di_def] = generatore_ipergrafi_generali_oggetti_imposti_source(N, card, numero_oggetti_imposto)

    mat_e_testa_di=zeros(1,N);
    mat_e_coda_di=zeros(1,N);

    riga=1;
    attivo=1;

    while riga<ceil(1.2*numero_oggetti_imposto)

        if (riga>=numero_oggetti_imposto && attivo==1)

            ultima_riga_utile=riga;
            attivo=0;

        end

        nodi_coinvolti=randperm(N,card);

        separatore_teste_code=card-1;

        for j=1:card

            if j<=separatore_teste_code

                mat_e_testa_di(riga,nodi_coinvolti(j))=nodi_coinvolti(j);

            else

                mat_e_coda_di(riga,nodi_coinvolti(j))=nodi_coinvolti(j);

            end

        end

        riga=riga+1;
        mat_e_coda_di=[mat_e_coda_di;zeros(1,N)];
        mat_e_testa_di=[mat_e_testa_di;zeros(1,N)];

    end

   mat_e_testa_di=mat_e_testa_di(1:riga-1,:);
   mat_e_coda_di=mat_e_coda_di(1:riga-1,:);

   matrice_complessiva=[mat_e_coda_di,mat_e_testa_di];

   %Rimuovo i duplicati

   matrice_complessiva1=unique(matrice_complessiva,"rows","stable");

   mat_e_coda_di=matrice_complessiva1(:,1:N);
   mat_e_testa_di=matrice_complessiva1(:,(N+1):end);

   aggiungo=0;

   mat_e_testa_di_def=mat_e_testa_di(1:ultima_riga_utile,:);
   mat_e_coda_di_def=mat_e_coda_di(1:ultima_riga_utile,:);

   while riga<numero_oggetti_imposto

       mat_e_testa_di_def=mat_e_testa_di(1:(ultima_riga_utile+aggiungo),:);
       mat_e_coda_di_def=mat_e_coda_di(1:(ultima_riga_utile+aggiungo),:);
       aggiungo=aggiungo+1;

   end

end