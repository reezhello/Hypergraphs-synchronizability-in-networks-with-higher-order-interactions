function [mat_e_testa_di, mat_e_coda_di] = generatore_ipergrafi_source_small_world(N, p, num_vicini)
    % num_vicini: definisce quanti iperarchi partono da ogni nodo i.
    % Se num_vicini = 1 -> vicini a distanza 1 (i+1, i-1)
    % Se num_vicini = 2 -> aggiunge anche iperarchi a distanza 2 (i+2, i-2), ecc.
    
    % Calcolo del numero totale di iperarchi
    num_iperarchi = N * num_vicini;
    
    % Inizializzazione delle matrici (righe = iperarchi, colonne = nodi)
    mat_e_testa_di = zeros(num_iperarchi, N);
    mat_e_coda_di = zeros(num_iperarchi, N);
    
    id_arco = 1; % Contatore per l'indice dell'iperarco corrente
    
    % 1. Generazione della struttura regolare iniziale
    for i = 1:N
        for dist = 1:num_vicini
            % Imposta la coda dell'iperarco
            mat_e_coda_di(id_arco, i) = i;
            
            % Calcola i vicini simmetrici a distanza 'dist' con logica circolare
            vicino_sinistro = mod(i - 1 - dist, N) + 1;
            vicino_destro = mod(i - 1 + dist, N) + 1;
            
            mat_e_testa_di(id_arco, vicino_sinistro) = vicino_sinistro;
            mat_e_testa_di(id_arco, vicino_destro) = vicino_destro;
            
            id_arco = id_arco + 1;
        end
    end
    
    % 2. Fase di Rewiring (Riconnessione casuale con probabilità p)
    % Scorriamo nuovamente tutti gli iperarchi creati per applicare il rewiring
    for id_arco = 1:num_iperarchi
        if rand < p
            % Trova qual è il nodo coda di questo iperarco
            nodo_coda = find(mat_e_coda_di(id_arco, :), 1);
            
            % Azzera le teste correnti di questo iperarco
            mat_e_testa_di(id_arco, :) = 0;
            
            % Estrae due nuove teste casuali che non siano il nodo coda
            teste_nuove = randperm(N, 2);
            while any(teste_nuove == nodo_coda)
                teste_nuove = randperm(N, 2);
            end
            
            % Assegna le nuove teste
            mat_e_testa_di(id_arco, teste_nuove) = teste_nuove;
        end
    end
end