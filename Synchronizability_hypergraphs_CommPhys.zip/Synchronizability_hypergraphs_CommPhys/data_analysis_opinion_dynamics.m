clear all 
close all 
clc

load('data_cases_opinion_dynamics.mat')
load('benchmark_synchronizability_opinion_dynamics.mat')

n_casi=8;
n_istanze_per_caso=10;

sincronizz_riferimento=10/risultati.bound_stimato

matrice_dati=zeros(n_casi,n_istanze_per_caso);

for i=1:n_casi

    BUFFER=RISULTATI_FINALI{i};

    for j=1:n_istanze_per_caso

        matrice_dati(i,j)=10/BUFFER(j).bound_stimato;

    end

end

vettore_sincronizz_medie=mean(matrice_dati,2);

vettore_deviazioni_standard=zeros(1,n_casi);

for i=1:n_casi

    vettore_deviazioni_standard(i)=std(matrice_dati(i,:));

end

vettore_dev_standard_percentuali=vettore_deviazioni_standard'/sincronizz_riferimento*100

vettore_percentuali_medie=vettore_sincronizz_medie/sincronizz_riferimento*100;

vettore_aumenti_diminuzioni_percentuali=vettore_percentuali_medie-100*ones(n_casi,1)