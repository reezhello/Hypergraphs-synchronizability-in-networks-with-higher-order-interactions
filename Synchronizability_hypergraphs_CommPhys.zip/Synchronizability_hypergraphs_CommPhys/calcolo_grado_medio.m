function grado_medio = calcolo_grado_medio(matrice)

    matrice_binaria=matrice~=0;

    vettore_gradi=sum(matrice_binaria,1);

    grado_medio=mean(vettore_gradi);

end