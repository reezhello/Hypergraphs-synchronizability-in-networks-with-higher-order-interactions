clear all 
close all 
clc

set(groot,'defaultAxesTickLabelInterpreter','latex')
set(groot,'defaultTextInterpreter','latex')

k=5;
kk=k;

load('gra_deg_cresc_kur_100top_eps1_v2.mat')
BUFFER{1}=RISULTATI_FINALI{1};
BUFFER{2}=RISULTATI_FINALI{2};
BUFFER{3}=RISULTATI_FINALI{3};
BUFFER{4}=RISULTATI_FINALI{4};
BUFFER{5}=RISULTATI_FINALI{5};
GRA_KUR=BUFFER;
load('hyp_deg_8_10_12_14_16_kur_tetra.mat')
IPER_KUR=RISULTATI_FINALI;
load('hyp_deg_8_10_12_14_16_source_kur_tetra.mat')
IPER_KUR_MAL=RISULTATI_FINALI;
load('hyp_deg_8_10_12_14_16_sink_kur_tetra.mat')
IPER_KUR_BEN=RISULTATI_FINALI;

n_gradi=5;
n_topologie=100;
n_tipi=4;
fs=13;

%Colori
nero=[0 0 0];
grigio=[0.6 0.6 0.6];
rosso_pallido=[0.3010 0.7450 0.9330];
bianco=[1 1 1];

%ANOVA

vettori_bound_stimati_grafi=cell(1,n_gradi);
vettori_bound_stimati_ipergrafi=cell(1,n_gradi);
vettori_bound_stimati_malefici=cell(1,n_gradi);
vettori_bound_stimati_benefici=cell(1,n_gradi);

for G=1:n_gradi

    vettore_grafi=zeros(1,n_topologie);
    vettore_ipergrafi=zeros(1,n_topologie);
    vettore_malefici=zeros(1,n_topologie);
    vettore_benefici=zeros(1,n_topologie);

    gruppo_graf=GRA_KUR{G};
    gruppo_iper_mix=IPER_KUR{G};
    gruppo_iper_mal=IPER_KUR_MAL{G};
    gruppo_iper_ben=IPER_KUR_BEN{G};

    for T=1:n_topologie

        if gruppo_graf(T).condition_number<1000 %questo valore deve essere abbastanza alto perchè voglio effettivamente eliminare i doppi zeri. Essi hanno un cn altissimo.

            vettore_grafi(T)=gruppo_graf(T).bound_stimato;

        end

        if gruppo_iper_mix(T).condition_number<1000

            vettore_ipergrafi(T)=gruppo_iper_mix(T).bound_stimato;
            
        end

        if gruppo_iper_mal(T).condition_number<1000

            vettore_malefici(T)=gruppo_iper_mal(T).bound_stimato;
            
        end

        if gruppo_iper_ben(T).condition_number<1000

            vettore_benefici(T)=gruppo_iper_ben(T).bound_stimato;
            
        end

    end

    vettori_bound_stimati_grafi{G}=nonzeros(vettore_grafi)';
    vettori_bound_stimati_ipergrafi{G}=nonzeros(vettore_ipergrafi)';
    vettori_bound_stimati_malefici{G}=nonzeros(vettore_malefici)';
    vettori_bound_stimati_benefici{G}=nonzeros(vettore_benefici)';

end

%Anova per grado 8 10 12 14 16

vettore_bound_anova_8=[1./vettori_bound_stimati_grafi{1},1./vettori_bound_stimati_ipergrafi{1},1./vettori_bound_stimati_malefici{1},1./vettori_bound_stimati_benefici{1}];
vettore_gruppi_anova_8=[ones(1,size(vettori_bound_stimati_grafi{1},2)), 2*ones(1,size(vettori_bound_stimati_ipergrafi{1},2)), 3*ones(1,size(vettori_bound_stimati_malefici{1},2)),4*ones(1,size(vettori_bound_stimati_benefici{1},2))];
[aov_kur_8,~,stats_kur_8]=anova1(vettore_bound_anova_8,vettore_gruppi_anova_8,"off");

[result_kur_8, means_8, ~, gnames]=multcompare(stats_kur_8,"CriticalValueType","tukey-kramer","Display","off");

vettore_bound_anova_10=[1./vettori_bound_stimati_grafi{2},1./vettori_bound_stimati_ipergrafi{2},1./vettori_bound_stimati_malefici{2},1./vettori_bound_stimati_benefici{2}];
vettore_gruppi_anova_10=[ones(1,size(vettori_bound_stimati_grafi{2},2)), 2*ones(1,size(vettori_bound_stimati_ipergrafi{2},2)), 3*ones(1,size(vettori_bound_stimati_malefici{2},2)),4*ones(1,size(vettori_bound_stimati_benefici{2},2))];
[aov_kur_10,~,stats_kur_10]=anova1(vettore_bound_anova_10,vettore_gruppi_anova_10,"off");

[result_kur_10, means_10, ~, gnames]=multcompare(stats_kur_10,"CriticalValueType","tukey-kramer","Display","off");

vettore_bound_anova_12=[1./vettori_bound_stimati_grafi{3},1./vettori_bound_stimati_ipergrafi{3},1./vettori_bound_stimati_malefici{3},1./vettori_bound_stimati_benefici{3}];
vettore_gruppi_anova_12=[ones(1,size(vettori_bound_stimati_grafi{3},2)), 2*ones(1,size(vettori_bound_stimati_ipergrafi{3},2)), 3*ones(1,size(vettori_bound_stimati_malefici{3},2)),4*ones(1,size(vettori_bound_stimati_benefici{3},2))];
[aov_kur_12,~,stats_kur_12]=anova1(vettore_bound_anova_12,vettore_gruppi_anova_12,"off");

[result_kur_12, means_12, ~, gnames]=multcompare(stats_kur_12,"CriticalValueType","tukey-kramer","Display","off");

vettore_bound_anova_14=[1./vettori_bound_stimati_grafi{4},1./vettori_bound_stimati_ipergrafi{4},1./vettori_bound_stimati_malefici{4},1./vettori_bound_stimati_benefici{4}];
vettore_gruppi_anova_14=[ones(1,size(vettori_bound_stimati_grafi{4},2)), 2*ones(1,size(vettori_bound_stimati_ipergrafi{4},2)), 3*ones(1,size(vettori_bound_stimati_malefici{4},2)),4*ones(1,size(vettori_bound_stimati_benefici{4},2))];
[aov_kur_14,~,stats_kur_14]=anova1(vettore_bound_anova_14,vettore_gruppi_anova_14,"off");

[result_kur_14, means_14, ~, gnames]=multcompare(stats_kur_14,"CriticalValueType","tukey-kramer","Display","off");

vettore_bound_anova_16=[1./vettori_bound_stimati_grafi{5},1./vettori_bound_stimati_ipergrafi{5},1./vettori_bound_stimati_malefici{5},1./vettori_bound_stimati_benefici{5}];
vettore_gruppi_anova_16=[ones(1,size(vettori_bound_stimati_grafi{5},2)), 2*ones(1,size(vettori_bound_stimati_ipergrafi{5},2)), 3*ones(1,size(vettori_bound_stimati_malefici{5},2)),4*ones(1,size(vettori_bound_stimati_benefici{5},2))];
[aov_kur_16,~,stats_kur_16]=anova1(vettore_bound_anova_16,vettore_gruppi_anova_16,"off");

[result_kur_16, means_16, ~, gnames]=multcompare(stats_kur_16,"CriticalValueType","tukey-kramer","Display","off");

%Figura Tukey Kramer test per grado 

medie=[mean(1./vettori_bound_stimati_grafi{k}), mean(1./vettori_bound_stimati_malefici{k}), mean(1./vettori_bound_stimati_ipergrafi{k}), mean(1./vettori_bound_stimati_benefici{k})];
medie=medie*10; %Moltiplico per radical N
errori_std=[std(1./vettori_bound_stimati_grafi{k})/sqrt(size(vettori_bound_stimati_grafi{k},2)), std(1./vettori_bound_stimati_malefici{k})/sqrt(size(vettori_bound_stimati_malefici{k},2)), std(1./vettori_bound_stimati_ipergrafi{k})/sqrt(size(vettori_bound_stimati_ipergrafi{k},2)), std(1./vettori_bound_stimati_benefici{k})/sqrt(size(vettori_bound_stimati_benefici{k},2))];
errori_std=errori_std*10; %Moltiplico per radical 10


figure
subplot(1,2,1)
B=bar(medie,0.7,'FaceColor','flat');
B.CData(1,:) = rosso_pallido;
B.CData(2,:) = nero;
B.CData(3,:) = grigio;
B.CData(4,:) = bianco;
hold on
b=errorbar(medie, errori_std,'vertical','LineStyle','none','LineWidth',2)
b.Color="#A2142F";
ylabel('$S$')
xticks([1 2 3 4])
xticklabels({'Digraphs', 'Source', 'ER', 'Sink'})
xtickangle(90)
yticks([0:30:180])
limy=[0 180];
ylim(limy)
title('Kuramoto model')
set(gca,'FontSize',fs)

%%ROSSLER

load('gra_deg_cresc_ross_100top_eps1_v2.mat')
BUFFER{1}=RISULTATI_FINALI{1};
BUFFER{2}=RISULTATI_FINALI{2};
BUFFER{3}=RISULTATI_FINALI{3};
BUFFER{4}=RISULTATI_FINALI{4};
BUFFER{5}=RISULTATI_FINALI{5};
GRA_ROSS=BUFFER;
load('hyp_deg_8_10_14_16_ross_tetra.mat')
IPER_ROSS=RISULTATI_FINALI;
IPER_ROSS{5}=IPER_ROSS{4};
IPER_ROSS{4}=IPER_ROSS{3};
load('hyp_deg_12_ross_tetra.mat')
IPER_ROSS{3}=RISULTATI_FINALI{1};
load('hyp_deg_8_10_14_16_source_ross_tetra.mat')
IPER_ROSS_MAL=RISULTATI_FINALI;
IPER_ROSS_MAL{5}=IPER_ROSS_MAL{4};
IPER_ROSS_MAL{4}=IPER_ROSS_MAL{3};
load('hyp_deg_12_source_ross_tetra.mat')
IPER_ROSS_MAL{3}=RISULTATI_FINALI{1};
load('hyp_deg_8_10_14_16_sink_ross_tetra.mat')
IPER_ROSS_BEN=RISULTATI_FINALI;
IPER_ROSS_BEN{5}=IPER_ROSS_BEN{4};
IPER_ROSS_BEN{4}=IPER_ROSS_BEN{3};
load('hyp_deg_12_sink_ross_tetra.mat')
IPER_ROSS_BEN{3}=RISULTATI_FINALI{1};

%Anova

vettori_bound_stimati_grafi=cell(1,n_gradi);
vettori_bound_stimati_ipergrafi=cell(1,n_gradi);
vettori_bound_stimati_malefici=cell(1,n_gradi);
vettori_bound_stimati_benefici=cell(1,n_gradi);

for G=1:n_gradi

    vettore_grafi=zeros(n_topologie,1);
    vettore_ipergrafi=zeros(n_topologie,1);
    vettore_malefici=zeros(n_topologie,1);
    vettore_benefici=zeros(n_topologie,1);

    gruppo_graf=GRA_ROSS{G};
    gruppo_iper_mix=IPER_ROSS{G};
    gruppo_iper_mal=IPER_ROSS_MAL{G};
    gruppo_iper_ben=IPER_ROSS_BEN{G};

    for T=1:n_topologie
        
        if gruppo_graf(T).bound_stimato>0

            vettore_grafi(T)=gruppo_graf(T).bound_stimato;

        end

        if gruppo_iper_mix(T).bound_stimato>0

            vettore_ipergrafi(T)=gruppo_iper_mix(T).bound_stimato;
            
        end

        if gruppo_iper_mal(T).bound_stimato>0

            vettore_malefici(T)=gruppo_iper_mal(T).bound_stimato;
            
        end

        if gruppo_iper_ben(T).bound_stimato>0

            vettore_benefici(T)=gruppo_iper_ben(T).bound_stimato;
            
        end

    end

    vettori_bound_stimati_grafi{G}=nonzeros(vettore_grafi)';
    vettori_bound_stimati_ipergrafi{G}=nonzeros(vettore_ipergrafi)';
    vettori_bound_stimati_malefici{G}=nonzeros(vettore_malefici)';
    vettori_bound_stimati_benefici{G}=nonzeros(vettore_benefici)';

end

%Anova per grado 8 10 12 14 16

vettore_bound_anova_8=[1./vettori_bound_stimati_grafi{1},1./vettori_bound_stimati_ipergrafi{1},1./vettori_bound_stimati_malefici{1},1./vettori_bound_stimati_benefici{1}];
vettore_gruppi_anova_8=[ones(1,size(vettori_bound_stimati_grafi{1},2)), 2*ones(1,size(vettori_bound_stimati_ipergrafi{1},2)), 3*ones(1,size(vettori_bound_stimati_malefici{1},2)),4*ones(1,size(vettori_bound_stimati_benefici{1},2))];
[aov_ross_8,~,stats_ross_8]=anova1(vettore_bound_anova_8,vettore_gruppi_anova_8,"off");

[result_ross_8, means_8, ~, gnames]=multcompare(stats_ross_8,"CriticalValueType","tukey-kramer","Display","off");

vettore_bound_anova_10=[1./vettori_bound_stimati_grafi{2},1./vettori_bound_stimati_ipergrafi{2},1./vettori_bound_stimati_malefici{2},1./vettori_bound_stimati_benefici{2}];
vettore_gruppi_anova_10=[ones(1,size(vettori_bound_stimati_grafi{2},2)), 2*ones(1,size(vettori_bound_stimati_ipergrafi{2},2)), 3*ones(1,size(vettori_bound_stimati_malefici{2},2)),4*ones(1,size(vettori_bound_stimati_benefici{2},2))];
[aov_ross_10,~,stats_ross_10]=anova1(vettore_bound_anova_10,vettore_gruppi_anova_10,"off");

[result_ross_10, means_10, ~, gnames]=multcompare(stats_ross_10,"CriticalValueType","tukey-kramer","Display","off");

vettore_bound_anova_12=[1./vettori_bound_stimati_grafi{3},1./vettori_bound_stimati_ipergrafi{3},1./vettori_bound_stimati_malefici{3},1./vettori_bound_stimati_benefici{3}];
vettore_gruppi_anova_12=[ones(1,size(vettori_bound_stimati_grafi{3},2)), 2*ones(1,size(vettori_bound_stimati_ipergrafi{3},2)), 3*ones(1,size(vettori_bound_stimati_malefici{3},2)),4*ones(1,size(vettori_bound_stimati_benefici{3},2))];
[aov_ross_12,~,stats_ross_12]=anova1(vettore_bound_anova_12,vettore_gruppi_anova_12,"off");

[result_ross_12, means_12, ~, gnames]=multcompare(stats_ross_12,"CriticalValueType","tukey-kramer","Display","off");

vettore_bound_anova_14=[1./vettori_bound_stimati_grafi{4},1./vettori_bound_stimati_ipergrafi{4},1./vettori_bound_stimati_malefici{4},1./vettori_bound_stimati_benefici{4}];
vettore_gruppi_anova_14=[ones(1,size(vettori_bound_stimati_grafi{4},2)), 2*ones(1,size(vettori_bound_stimati_ipergrafi{4},2)), 3*ones(1,size(vettori_bound_stimati_malefici{4},2)),4*ones(1,size(vettori_bound_stimati_benefici{4},2))];
[aov_ross_14,~,stats_ross_14]=anova1(vettore_bound_anova_14,vettore_gruppi_anova_14,"off");

[result_ross_14, means_14, ~, gnames]=multcompare(stats_ross_14,"CriticalValueType","tukey-kramer","Display","off");

vettore_bound_anova_16=[1./vettori_bound_stimati_grafi{4},1./vettori_bound_stimati_ipergrafi{4},1./vettori_bound_stimati_malefici{4},1./vettori_bound_stimati_benefici{4}];
vettore_gruppi_anova_16=[ones(1,size(vettori_bound_stimati_grafi{4},2)), 2*ones(1,size(vettori_bound_stimati_ipergrafi{4},2)), 3*ones(1,size(vettori_bound_stimati_malefici{4},2)),4*ones(1,size(vettori_bound_stimati_benefici{4},2))];
[aov_ross_16,~,stats_ross_16]=anova1(vettore_bound_anova_16,vettore_gruppi_anova_16,"off");

[result_ross_16, means_16, ~, gnames]=multcompare(stats_ross_16,"CriticalValueType","tukey-kramer","Display","off");

%Figure Tukey-Kramer 

medie=[mean(1./vettori_bound_stimati_grafi{kk}), mean(1./vettori_bound_stimati_malefici{kk}), mean(1./vettori_bound_stimati_ipergrafi{kk}), mean(1./vettori_bound_stimati_benefici{kk})];
medie=medie*10; %Moltiplico per radical N
errori_std=[std(1./vettori_bound_stimati_grafi{kk})/sqrt(size(vettori_bound_stimati_grafi{kk},2)), std(1./vettori_bound_stimati_malefici{kk})/sqrt(size(vettori_bound_stimati_malefici{kk},2)), std(1./vettori_bound_stimati_ipergrafi{kk})/sqrt(size(vettori_bound_stimati_ipergrafi{kk},2)), std(1./vettori_bound_stimati_benefici{kk})/sqrt(size(vettori_bound_stimati_benefici{kk},2))];
errori_std=errori_std*10; %Moltiplico per radical N

subplot(1,2,2)
B=bar(medie,0.7,'FaceColor','flat');
B.CData(1,:) = rosso_pallido;
B.CData(2,:) = nero;
B.CData(3,:) = grigio;
B.CData(4,:) = bianco;
hold on
b=errorbar(medie, errori_std,'vertical','LineStyle','none','LineWidth',2)
b.Color="#A2142F";
ylabel('$S$')
xticks([1 2 3 4])
xticklabels({'Digraphs', 'Source', 'ER', 'Sink'})
yticks([0:250:1250])
xtickangle(90)
limy=[0 1250];
ylim(limy)
title('R\"ossler systems')
set(gca,'FontSize',fs)

set(gcf, 'Position',  [250, 125, 825, 350]);
